-- =====================================================
-- HUD SERVER — Bootstrap
-- =====================================================
-- Nome com "_" de propósito: carrega antes dos outros arquivos de
-- server-side/* (ordem alfabética), que dependem de `vRP` e `HUD`
-- já existirem. Mesmo truque usado em shared-side/_shared.lua.
--
-- `vRP`  = Proxy.getInterface("vRP")  -> chama as funções do vRP core
--          (server) que este resource não pode nem deve reimplementar
--          (dinheiro, identidade, permissões, inventário...).
-- `HUD`  = interface Tunnel exposta ao client deste resource. O
--          client já chama `vSERVER.<Funcao>(...)` (client-side/*.lua)
--          esperando este lado responder — antes desta pasta existir
--          essas chamadas simplesmente não tinham quem atender.
-- =====================================================

local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")

vRP = Proxy.getInterface("vRP")

HUD = {}
Tunnel.bindInterface("hud",HUD)

-----------------------------------------------------------------------------------------------------------------------------------------
-- SETUSERID
-----------------------------------------------------------------------------------------------------------------------------------------
-- O client (client-side/client.lua) só mostra o `user_id` correto depois de receber
-- este evento (ou do statebag `Passport`, que nem sempre chega cedo o bastante). O vRP
-- core dispara "CharacterChosen" assim que o personagem entra em jogo — é o gancho certo
-- para avisar a HUD sem duplicar a lógica de spawn do vRP.
AddEventHandler("CharacterChosen",function(Passport,source)
	if not Passport or not source then
		return
	end

	TriggerClientEvent("hud:setUserId",source,parseInt(Passport))
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- FETCHBINDS
-----------------------------------------------------------------------------------------------------------------------------------------
-- client-side/client.lua -> RegisterNUICallback('fetch:binds', ...) -> vSERVER.fetchBinds()
-- Não existe um sistema de "keybind de item" separado no vRP desta base; o inventário do
-- jogador É a fonte real dos itens que a HUD pode exibir na barra rápida.
function HUD.fetchBinds()
	local source = source
	local Passport = vRP.Passport(source)
	if not Passport then
		return {}
	end

	return vRP.Inventory(Passport)
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- GETUSERNAME
-----------------------------------------------------------------------------------------------------------------------------------------
-- client-side/client.lua -> getPlayerData(source) -> vSERVER.getUserName(source)
-- Usado para identificar quem está falando no rádio (source = server id do outro jogador).
function HUD.getUserName(TargetSource)
	local TargetPassport = vRP.Passport(tonumber(TargetSource))
	if not TargetPassport then
		return { id = 0, name = "Desconhecido" }
	end

	return { id = TargetPassport, name = vRP.FullName(TargetPassport) }
end

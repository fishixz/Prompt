-- =====================================================
-- HUD SERVER — Veículos (nitro, rua atual, ejeção por cinto)
-- =====================================================

local NITRO_MAX_FUEL = 2000
local STREET_NAME_MAX_LENGTH = 100

-----------------------------------------------------------------------------------------------------------------------------------------
-- UPDATENITRO  (nitro.lua -> vSERVER.UpdateNitro(plate, fuel))
-----------------------------------------------------------------------------------------------------------------------------------------
-- O nível de nitro do veículo mora em `GlobalState["Nitro:"..Plate]` — é isso que o client
-- já lê de volta (client-side/client.lua e nitro.lua). O servidor só garante que quem está
-- salvando o valor realmente está DENTRO do veículo daquela placa, e limita o valor.
function HUD.UpdateNitro(Plate,Fuel)
	local source = source
	local Passport = vRP.Passport(source)
	if not Passport then
		return false
	end

	if type(Plate) ~= "string" or Plate == "" or #Plate > 12 then
		return false
	end

	local Ped = GetPlayerPed(source)
	local Vehicle = GetVehiclePedIsIn(Ped,false)
	if Vehicle == 0 then
		return false
	end

	local CurrentPlate = GetVehicleNumberPlateText(Vehicle):gsub("%s+","")
	if CurrentPlate ~= Plate:gsub("%s+","") then
		return false
	end

	GlobalState["Nitro:"..Plate] = math.max(0,math.min(parseInt(Fuel),NITRO_MAX_FUEL))

	return true
end
-----------------------------------------------------------------------------------------------------------------------------------------
-- UPDATEPLAYERSTREET  (client.lua -> TriggerServerEvent('updatePlayerStreet', streetName))
-----------------------------------------------------------------------------------------------------------------------------------------
-- Guarda a rua atual como statebag: barato de manter e permite que outros resources (rádio
-- da polícia, despacho, admin) leiam onde o jogador está sem reimplementar a leitura de rua.
RegisterServerEvent("updatePlayerStreet")
AddEventHandler("updatePlayerStreet",function(StreetName)
	local source = source
	local Passport = vRP.Passport(source)
	if not Passport then
		return
	end

	if type(StreetName) ~= "string" or StreetName == "" or #StreetName > STREET_NAME_MAX_LENGTH then
		return
	end

	Player(source).state.Street = StreetName
end)
-----------------------------------------------------------------------------------------------------------------------------------------
-- VEHICLEEJECT  (client.lua -> EjectFromVehicle -> TriggerServerEvent("hud:VehicleEject", velocity))
-----------------------------------------------------------------------------------------------------------------------------------------
-- O client só cuida do visual (remove colisão, empurra o ped pra fora). A consequência de
-- verdade — dano proporcional à velocidade da ejeção — é decidida aqui: o client nunca é
-- dono do resultado de algo que afeta a vida do próprio jogador.
local EJECT_MAX_DAMAGE = 60
local EJECT_SPEED_DIVISOR = 3

RegisterServerEvent("hud:VehicleEject")
AddEventHandler("hud:VehicleEject",function(Velocity)
	local source = source
	local Passport = vRP.Passport(source)
	if not Passport or type(Velocity) ~= "vector3" then
		return
	end

	local Speed = #Velocity * 2.236936
	local Damage = math.min(math.floor(Speed / EJECT_SPEED_DIVISOR),EJECT_MAX_DAMAGE)
	if Damage <= 0 then
		return
	end

	local Ped = GetPlayerPed(source)
	if DoesEntityExist(Ped) then
		SetEntityHealth(Ped,math.max(GetEntityHealth(Ped) - Damage,0))
	end
end)

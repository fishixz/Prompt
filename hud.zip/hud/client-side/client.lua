-- =====================================================
-- HUD System Otimizado - FiveM
-- =====================================================
-- Dependências
local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")
vRP = Proxy.getInterface("vRP")
vSERVER = Tunnel.getInterface("hud")
vRPserver = Tunnel.getInterface("vRP")

--- Pedido de formulario em curso, um por chamada de `DS.Formulary`.
---
--- Era estado GLOBAL (`Response`/`ForceClosed`) partilhado por TODOS os formularios deste
--- cliente, e por isso um formulario cancelado envenenava o seguinte: o `formularyClosed`
--- levantava `ForceClosed` durante 500 ms e o laco so olhava de segundo a segundo, entao a
--- janela passava despercebida e o laco do formulario cancelado ficava vivo ate aos 120 s.
--- Quando o jogador respondia o formulario SEGUINTE, os dois lacos acordavam no mesmo
--- `Response`: o zombie levava a resposta e punha `Response = nil`, e o chamador de verdade
--- voltava a esperar ate ao timeout -- a etapa seguinte da corrente (`/eventosadmin`,
--- `/weapon`) nunca abria.
---
--- Agora cada chamada tem o seu pedido e a NUI so resolve o que esta ativo.
---@type { done: boolean, response: table|false|nil }|nil
local ActiveFormulary = nil

--- Encerra o pedido em curso, se houver.
---@param response table|false tabela sanitizada, ou `false` se fechou sem responder
local function ResolveFormulary(response)
    local request = ActiveFormulary
    if not request then return end

    ActiveFormulary = nil
    request.response = response
    request.done = true
end

-- Interface
local DS = {}
Tunnel.bindInterface("hud", DS)
-- Estados do jogador
local PlayerState = {
    user_id = 0,
    hunger = hudConfig['hungerValue'] or 0,
    thirst = hudConfig['thirstValue'] or 0,
    gems = 0,
    showHud = true,
    isActive = false,
    inVehicle = false,
    seatbelt = false,
    isMotorcycle = false,
    toggleCapuz = false,
    hideMap = GetResourceKvpInt('hud:hideMap') == 1
}

-- =====================================================
-- TRAVA DE PARTIDA
-- =====================================================
-- Enquanto uma partida (arena, evento, FFA, corrida) estiver no ar, a HUD da cidade fica
-- escondida e ESTE resource não toma foco de NUI — mesmo que outro script peça o contrário.
--
-- Existe porque "esconder a HUD" sempre foi um pedido isolado e reversível: mais de vinte
-- resources devolvem `hud:Active true` ao fechar a própria tela, sem ler como ela estava.
-- Bastava o jogador abrir e fechar academia, loja ou qualquer painel no meio do round para
-- a HUD da cidade voltar por cima da partida — e a reafirmação de 5s a mantinha ligada.
-- Corrigir resource por resource seria caçar vinte lugares, e o próximo a ser escrito
-- recomeçaria o problema; a trava põe a decisão em quem tem autoridade sobre ela.
--
-- A trava é por DONO (o resource que pediu), então evento e arena podem segurá-la ao mesmo
-- tempo e cada um soltar a sua sem desfazer a do outro.
--
-- Ela NÃO mexe em `PlayerState.showHud`: esse continua sendo o que a CIDADE quer, e é o que
-- volta a valer quando o último dono solta. Quem joga com a HUD desligada de propósito
-- continua com ela desligada no fim da partida.
local HudLocks = {}

---@return boolean
local function IsHudLocked()
    return next(HudLocks) ~= nil
end

-- Make hunger and thirst globally accessible for functions.lua
hunger = 100 -- Default value
thirst = 100 -- Default value

-- Function to sync global variables with PlayerState
local function syncNeedsVariables()
    hunger = PlayerState.hunger
    thirst = PlayerState.thirst
end

-- Estados do veículo
local VehicleState = {
    nitro = 0,
    nitroFuel = 0,
    lastVehicle = nil,
    handbrake = 0,
    seatbeltSpeed = 0,
    seatbeltVelocity = vec3(0, 0, 0)
}

-- Estados de comunicação
local CommState = {
    radioPlayers = {},
    talking = 2,
    frequency = 'OFF',
    isSpeaking = false
}

-- Cache e performance
local Cache = {
    ped = nil,
    vehicle = nil,
    coords = nil,
    lastUpdate = 0,
    updateInterval = 500
}

local RadioFrequency = {
    cachedData = {},
    talking = {}
}

-- Constantes
local CONSTANTS = {
    UPDATE_INTERVALS = {
        MAIN_HUD = 500,
        VEHICLE_DAMAGE = 100,
        SEATBELT = 50,
        NEEDS_DAMAGE = 5000
    },
    SEATBELT_EJECT_SPEED = 50,
    DAMAGE_THRESHOLDS = {
        LOW = { min = 3, max = 5, damage = 1 },
        HIGH = { min = 0, max = 2, damage = 2 }
    }
}

-- =====================================================
-- DIFF DE PAYLOAD NUI
-- Só reenvia os campos que realmente mudaram desde o último tick,
-- evitando postar o payload inteiro (e re-parsear JSON no CEF) toda hora.
-- =====================================================
local function pushHudDiff(cache, data)
    local diff, has = {}, false
    for k, v in pairs(data) do
        if cache[k] ~= v then
            cache[k] = v
            diff[k] = v
            has = true
        end
    end
    if has then
        SendNUIMessage({ action = 'set:hud', data = diff })
    end
end

-- armory é tabela aninhada (difere sempre por referência); comparamos por assinatura.
local function armorySignature(w)
    if not w.active then return "0" end
    return "1|" .. tostring(w.index) .. "|" .. tostring(w.wammo) .. "|" .. tostring(w.reload) .. "|" .. tostring(w.isWeapon)
end

local hudCache = {}        -- cache do loop principal
local vehCache = {}        -- cache do loop de veículo
local lastArmorySig = nil
local radarShown = false
local lastSentStreet = nil

-- =====================================================
-- FUNÇÕES UTILITÁRIAS
-- =====================================================

-- Cache do PlayerPedId para reduzir chamadas nativas
local function GetCachedPed()
    local currentTime = GetGameTimer()
    if not Cache.ped or currentTime - Cache.lastUpdate > 100 then
        Cache.ped = PlayerPedId()
        Cache.lastUpdate = currentTime
    end
    return Cache.ped
end

-- Função para atualizar visibilidade do radar de forma otimizada
local function UpdateRadarVisibility()
    local ped = GetCachedPed()
    local inVehicle = IsPedInAnyVehicle(ped, false)
    
    -- Verifica se está criando/selecionando personagem
    local isCreatingCharacter = LocalPlayer.state.onCreate or 
                               LocalPlayer.state.editChar or 
                               LocalPlayer.state.onSpawnSelect
    
    if isCreatingCharacter then
        DisplayRadar(false)
        radarShown = false
        return
    end
    
    -- Se a HUD está desativada — ou travada por uma partida —, esconde o minimapa
    if not PlayerState.showHud or IsHudLocked() then
        DisplayRadar(false)
        radarShown = false
        return
    end

    -- Se o jogador ocultou o minimapa, não mostra
    if PlayerState.hideMap then
        DisplayRadar(false)
        radarShown = false
        return
    end
    
    -- Lógica simplificada para mostrar radar
    local shouldShowRadar = inVehicle or hudConfig.pinTheMinimap
    DisplayRadar(shouldShowRadar)

    -- Só refaz o fetch das dimensões quando o radar PASSA a ser exibido
    -- (antes era enviado a cada tick enquanto o radar estivesse visível).
    if shouldShowRadar and not radarShown then
        SendNUIMessage({
            action = "refetch:minimapDimensions",
            data = {}
        })
    end
    radarShown = shouldShowRadar
end

--- Manda para a NUI o que a HUD DEVE estar mostrando agora.
---
--- Um lugar só de propósito: o estado sai de duas fontes (o que a cidade quer e se há
--- partida travando), e espalhar essa conta pelos chamadores é como o resource chegou a
--- ter quatro caminhos discordando sobre a mesma página.
local function ApplyHudVisibility()
    local visible = PlayerState.showHud == true and not IsHudLocked()

    -- Espelho PÚBLICO, porque `PlayerState` é local DESTE arquivo e o `chat.lua`,
    -- o `policeAlerts.lua` e o `keybinds.lua` precisam da informação: os três abrem coisa
    -- que mora na MESMA página da HUD, e sem saber que ela está escondida tomavam o foco
    -- com a tela vazia — o "mouse travado no round". Ver `openChat`.
    HudVisible = visible

    SendNUIMessage({ action = 'set:visible', data = visible })
    UpdateRadarVisibility()
end


function GetMinimapPosition()
    local minimap = {}
    local resX, resY = GetActiveScreenResolution()
    local aspectRatio = GetAspectRatio()
    local scaleX = 1/resX
    local scaleY = 1/resY
    local minimapRawX, minimapRawY
    SetScriptGfxAlign(string.byte('L'), string.byte('B'))
    if IsBigmapActive() then
        minimapRawX, minimapRawY = GetScriptGfxPosition(-0.003975, 0.022 + (-0.460416666))
        minimap.width = scaleX*(resX/(2.52*aspectRatio))
        minimap.height = scaleY*(resY/(2.3374))
    else
        minimapRawX, minimapRawY = GetScriptGfxPosition(-0.0045, 0.002 + (-0.188888))
        minimap.width = scaleX*(resX/(4*aspectRatio))
        minimap.height = scaleY*(resY/(5.674))
    end
    ResetScriptGfxAlign()
    minimap.leftX = minimapRawX
    minimap.rightX = minimapRawX+minimap.width
    minimap.topY = minimapRawY
    minimap.bottomY = minimapRawY+minimap.height
    minimap.X = minimapRawX+(minimap.width/2)
    minimap.Y = minimapRawY+(minimap.height/2)

    for k in pairs(minimap) do
        minimap[k] = minimap[k] * 100
    end


    return minimap
end

-- Ejeção do veículo otimizada
local function EjectFromVehicle(velocity)
    TriggerEvent("ragdoll", true)
    
    local ped = GetCachedPed()
    local vehicle = GetVehiclePedIsIn(ped, false)
    
    SetEntityNoCollisionEntity(ped, vehicle, false)
    SetEntityNoCollisionEntity(vehicle, ped, false)
    
    TriggerServerEvent("hud:VehicleEject", velocity)
    
    Wait(500)
    
    SetEntityNoCollisionEntity(ped, vehicle, true)
    SetEntityNoCollisionEntity(vehicle, ped, true)
end

-- =====================================================
-- EVENTOS E HANDLERS OTIMIZADOS
-- =====================================================

-- Eventos de fome e sede otimizados
RegisterNetEvent("hud:Hunger", function(number)
    PlayerState.hunger = math.min(parseInt(number) or 0, 100)
    syncNeedsVariables() -- Update global variables
end)

RegisterNetEvent("hud:Thirst", function(number)
    PlayerState.thirst = math.min(parseInt(number) or 0, 100)
    syncNeedsVariables() -- Update global variables
end)

RegisterNetEvent("hud:setUserId", function(number)
    PlayerState.user_id = number
    SendNUIMessage({
        action = 'set:hud',
        data = {
            user_id = PlayerState.user_id
        }
    })
end)

-- Handler para mudança de Passport otimizado
AddStateBagChangeHandler("Passport", ("player:%s"):format(LocalPlayer.state.Player), function(_, _, value)
    PlayerState.user_id = value
end)

RegisterNetEvent("hud:updateGems", function(number)
    PlayerState.gems = number
    SendNUIMessage({
        action = 'set:hud',
        data = {
            gems = PlayerState.gems
        }
    })
end)

-- O vRP core (identity.lua, money.lua, base.lua) nunca dispara "hud:updateGems" -- ele
-- soma/subtrai via "hud:AddGemstone"/"hud:RemoveGemstone". Sem estes dois handlers o
-- contador de gemas da HUD ficava sempre zerado, por mais que o jogador comprasse ou
-- gastasse diamantes.
RegisterNetEvent("hud:AddGemstone", function(number)
    PlayerState.gems = (PlayerState.gems or 0) + (parseInt(number) or 0)
    SendNUIMessage({
        action = 'set:hud',
        data = {
            gems = PlayerState.gems
        }
    })
end)

RegisterNetEvent("hud:RemoveGemstone", function(number)
    PlayerState.gems = math.max((PlayerState.gems or 0) - (parseInt(number) or 0), 0)
    SendNUIMessage({
        action = 'set:hud',
        data = {
            gems = PlayerState.gems
        }
    })
end)
-- =====================================================
-- CALLBACKS NUI OTIMIZADOS
-- =====================================================
-- A NUI nao e fronteira de seguranca: qualquer jogador com o devtools chama esse
-- callback com o payload que quiser (tipo errado, tabela aninhada, string de MB).
-- Aqui so passa `{ data = { [string] = string } }` dentro de limites; o resto morre.
local FORMULARY_MAX_FIELDS = 24
local FORMULARY_MAX_KEY = 64
local FORMULARY_MAX_VALUE = 4096

local function sanitizeFormularyResponse(payload)
    if type(payload) ~= 'table' or type(payload.data) ~= 'table' then
        return { data = {} }
    end

    local sanitized = {}
    local fields = 0

    for key, value in pairs(payload.data) do
        if fields >= FORMULARY_MAX_FIELDS then break end

        if type(key) == 'string' and type(value) == 'string' then
            sanitized[string.sub(key, 1, FORMULARY_MAX_KEY)] = string.sub(value, 1, FORMULARY_MAX_VALUE)
            fields = fields + 1
        end
    end

    return { data = sanitized }
end

RegisterNUICallback('formularyResponse', function(data, cb)
    SetNuiFocus(false, false)
    ResolveFormulary(sanitizeFormularyResponse(data))
    return cb('Ok')
end)

RegisterNUICallback('fetch:binds', function(data, cb)
    local items = vSERVER.fetchBinds()  
    cb(items)
end)

RegisterNUICallback('fetchHudLogo', function(_, cb)
    cb(hudConfig.logoUrl)
end)

RegisterNUICallback('getCityName', function(_, cb)
    cb("AMERICA")
end)

RegisterNUICallback('remove:focus', function(_, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNUICallback('fetchMapPosition', function(_, cb)
    cb(GetMinimapPosition())
end)

-- =====================================================
-- CALLBACKS DE VISIBILIDADE DO MINIMAPA
-- =====================================================
RegisterNUICallback('get:hidemap', function(_, cb)
    cb(PlayerState.hideMap)
end)

RegisterNUICallback('post:toggleHidemap', function(_, cb)
    PlayerState.hideMap = not PlayerState.hideMap
    SetResourceKvpInt('hud:hideMap', PlayerState.hideMap and 1 or 0)
    UpdateRadarVisibility()
    cb(true)
end)

-- =====================================================
-- SISTEMA DE VEÍCULOS OTIMIZADO
-- =====================================================

-- Gerenciamento de entrada no veículo
AddEventHandler("gameEventTriggered", function(eventName, args)
    if eventName ~= "CEventNetworkPlayerEnteredVehicle" then return end
    if args[1] ~= NetworkGetPlayerIndexFromPed(PlayerPedId()) then return end
    
    PlayerState.inVehicle = true
    PlayerState.seatbelt = false
    UpdateRadarVisibility()
    
    local currentVehicle = GetVehiclePedIsIn(PlayerPedId(), false)
    if currentVehicle and currentVehicle ~= 0 then
        VehicleState.seatbeltSpeed = GetEntitySpeed(currentVehicle) * 2.236936
        VehicleState.seatbeltVelocity = GetEntityVelocity(currentVehicle)
    else
        VehicleState.seatbeltSpeed = 0
        VehicleState.seatbeltVelocity = vec3(0, 0, 0)
    end
    
    CreateThread(function()
        local ped = GetCachedPed()
        vehCache = {} -- novo veículo: garante um primeiro envio completo

        while PlayerState.inVehicle and IsPedInAnyVehicle(ped, false) do
            local vehicle = GetVehiclePedIsIn(ped, false)
            if not vehicle or vehicle == 0 then break end
            
            -- Verifica se é motocicleta
            PlayerState.isMotorcycle = GetVehicleClass(vehicle) == 8
            if PlayerState.isMotorcycle then
                DisplayRadar(true)
            end
            
            -- Coleta dados do veículo de forma otimizada
            local vehicleData = {
                speed = hudConfig.getSpeedVehicle(vehicle),
                fuel = GetVehicleFuelLevel(vehicle),
                engine = GetVehicleEngineHealth(vehicle) / 10,
                rpm = GetVehicleCurrentRpm(vehicle),
                gear = GetVehicleCurrentGear(vehicle),
                vehicleOn = GetIsVehicleEngineRunning(vehicle),
                plate = GetVehicleNumberPlateText(vehicle)
            }
            
            -- Lógica da marcha otimizada
            if (vehicleData.speed == 0 and vehicleData.gear == 0) or 
               (vehicleData.speed == 0 and vehicleData.gear == 1) then
                vehicleData.gear = "N"
            elseif vehicleData.speed > 0 and vehicleData.gear == 0 then
                vehicleData.gear = "R"
            end
            
            -- Lógica das luzes
            local _, light, fullLight = GetVehicleLightsState(vehicle)
            local lightOn = light == 1 or fullLight == 1
            local highLight = fullLight == 1
            
            -- Lógica do nitro otimizada
            if LocalPlayer.state.Nitro then
                VehicleState.nitro = VehicleState.nitroFuel
            else
                VehicleState.nitro = GlobalState["Nitro:" .. vehicleData.plate] or VehicleState.nitroFuel
            end
            
            local nitroHud = VehicleState.nitro > 0 and parseInt((VehicleState.nitro * 100) / 2000) or 0
            
            pushHudDiff(vehCache, {
                isDriving = true,
                RPM = math.min(vehicleData.rpm, 1.0),
                speed = vehicleData.speed,
                nitro = nitroHud,
                gear = vehicleData.gear,
                engine = vehicleData.engine,
                gas = vehicleData.fuel,
                light = lightOn,
                highLight = highLight,
                lock = GetVehicleDoorLockStatus(vehicle) == 2,
                seatbelt = PlayerState.seatbelt,
                isMotorcycle = PlayerState.isMotorcycle,
                ignition = vehicleData.vehicleOn,
                headlight = lightOn
            })

            Wait(150)
        end
        
        -- Cleanup ao sair do veículo

        PlayerState.inVehicle = false
        PlayerState.seatbelt = false
        
        if not hudConfig.pinTheMinimap then
            DisplayRadar(false)
        end
        
        SendNUIMessage({
            action = 'set:hud',
            data = {
                isDriving = false,
                speed = 0,
                engine = 0,
                gas = 0,
                nitro = 0,
                light = false,
                lock = false,
                seatbelt = false,
                isMotorcycle = false,
            }
        })
    end)
    
    -- Thread para sistema de cinto de segurança
    CreateThread(function()
        local enterCooldown = true
        Wait(1500)
        enterCooldown = false
        
        local ped = GetCachedPed()
        local vehicle = GetVehiclePedIsIn(ped, false)
        if vehicle and vehicle ~= 0 then
            VehicleState.seatbeltSpeed = GetEntitySpeed(vehicle) * 2.236936
            VehicleState.seatbeltVelocity = GetEntityVelocity(vehicle)
        end
        
        while PlayerState.inVehicle do
            ped = GetCachedPed()
            vehicle = GetVehiclePedIsIn(ped, false)
            
            local isEnteringOrExiting = GetIsTaskActive(ped, 160) or -- TASK_ENTER_VEHICLE
                                        GetIsTaskActive(ped, 161) or -- TASK_EXIT_VEHICLE
                                        GetIsTaskActive(ped, 167) or -- TASK_OPEN_VEHICLE_DOOR
                                        not IsPedInAnyVehicle(ped, false)
            
            if vehicle and vehicle ~= 0 and not IsPedOnAnyBike(ped) and 
               not IsPedInAnyHeli(ped) and not IsPedInAnyPlane(ped) and
               not IsPedInAnyBoat(ped) and
               not isEnteringOrExiting and not enterCooldown then
                
                local speed = GetEntitySpeed(vehicle) * 2.236936
                
                if speed ~= VehicleState.seatbeltSpeed then
                    if (VehicleState.seatbeltSpeed - speed) >= 60 and not PlayerState.seatbelt and not LocalPlayer.state.SafeZone and not LocalPlayer.state.inRacing and not LocalPlayer.state.inEvent then
                        EjectFromVehicle(VehicleState.seatbeltVelocity)
                    end
                    
                    VehicleState.seatbeltVelocity = GetEntityVelocity(vehicle)
                    VehicleState.seatbeltSpeed = speed
                end
            end
            
            Wait(CONSTANTS.UPDATE_INTERVALS.SEATBELT)
        end
    end)
end)

local actualStreetName = nil
local pauseBreak = false

-- =====================================================
-- LOOP PRINCIPAL DA HUD OTIMIZADO
-- =====================================================

CreateThread(function()
    -- Aguarda jogador estar ativo
    while not LocalPlayer.state.Active do
        SendNUIMessage({ action = 'set:visible', data = false })
        DisplayRadar(false)
        Wait(100)
    end
    
    LoadPtfxAsset("veh_xs_vehicle_mods")
    RegisterKeyMapping("+shortcuts", "Visualizar atalhos.", "keyboard", "TAB")
    
    Wait(1000)
    
    -- Aguarda sair da tela de criação/seleção antes de mostrar a HUD
    while LocalPlayer.state.onCreate or LocalPlayer.state.editChar or LocalPlayer.state.onSpawnSelect do
        SendNUIMessage({ action = 'set:visible', data = false })
        DisplayRadar(false)
        Wait(500)
    end
    
    -- Ativa a HUD ao inicializar
    PlayerState.showHud = true
    HudVisible = true
    SendNUIMessage({ action = 'set:visible', data = true })
    
    -- Inicializa HUD
    SendNUIMessage({
        action = 'set:hud',
        data = {
            isDriving = false,
            isSpeaking = CommState.talking,
            zone = false,
            radio = CommState.frequency
        }
    })
    
    while true do
        local idle = 5000
        
        -- Verifica se está criando personagem
        local isCreatingCharacter = LocalPlayer.state.onCreate or 
                                   LocalPlayer.state.editChar or 
                                   LocalPlayer.state.onSpawnSelect
        
        if isCreatingCharacter then
            idle = 1000
            PlayerState.isActive = false
            SendNUIMessage({ action = 'set:visible', data = false })
            DisplayRadar(false)
        -- `IsHudLocked` junto: sem ele este ramo reexibia a HUD no meio da partida
        -- assim que o jogador saísse da tela de criação, ou logo depois de qualquer
        -- resource pedir `hud:Active true`.
        elseif LocalPlayer.state.Active and PlayerState.showHud and not IsHudLocked() then
            if not PlayerState.isActive then
                PlayerState.isActive = true
                hudCache = {}       -- força reenvio completo ao (re)exibir a HUD
                lastArmorySig = nil
                SendNUIMessage({ action = 'set:visible', data = true })
                -- baseUrl é estático: envia uma vez por ativação, não a cada tick
                SendNUIMessage({
                    action = 'set:hud',
                    data = {
                        baseUrl = {
                            items = hudConfig.itemsUrl,
                            armory = hudConfig.armoryUrl
                        }
                    }
                })
            end
            idle = CONSTANTS.UPDATE_INTERVALS.MAIN_HUD
            
            local ped = GetCachedPed()
            local player = PlayerId()
            
            -- Coleta dados do jogador de forma otimizada
            local playerData = {
                life = math.max(hudConfig.getLifeCalculate(ped), 0),
                stamina = hudConfig.getPlayerStamina(player),
                armour = hudConfig.getPedArmour(ped),
                coords = GetEntityCoords(ped),
                isArmed = IsPedArmed(ped, 6) or IsPedArmed(ped, 1),
                isSpeaking = NetworkIsPlayerTalking(player)
            }
            
            -- Nome da rua otimizado
            local streetHash = GetStreetNameAtCoord(playerData.coords.x, playerData.coords.y, playerData.coords.z)
            local streetName = GetStreetNameFromHashKey(streetHash)
            
            -- LocalPlayer.state:set("onStreet", streetName, true)
            
            if hudConfig.modifyStreetNames and hudConfig.modifyStreets[streetName] then
                streetName = hudConfig.modifyStreets[streetName]
            end

            actualStreetName = streetName
            
            -- Tempo formatado
            local hours, minutes = tonumber(GlobalState.Hours) or 0, tonumber(GlobalState.Minutes) or 0
            local timeString = string.format("%02d:%02d", hours, minutes)
            
            -- Dados da arma
            local weaponData = {}
            if playerData.isArmed then
                idle = 200
                local weapon = GetSelectedPedWeapon(ped)
                local totalAmmo = GetAmmoInPedWeapon(ped, weapon)
                local _, clipAmmo = GetAmmoInClip(ped, weapon)

                local weaponName = Weapons[weapon]
                if not weaponName then
                    if GetResourceState('europa_skins') == 'started' then
                        weaponName = exports.europa_skins:getWeaponBySkin(weapon) or "Arma Desconhecida"
                    else
                        weaponName = "Arma Desconhecida"
                    end
                end

                weaponData = {
                    active = true,
                    index = tostring(itemIndex(weaponName)),
                    isWeapon = not IsPedArmed(ped, 1),
                    wammo = clipAmmo,
                    reload = totalAmmo - clipAmmo
                }
            else
                weaponData.active = false
            end
            
            -- Envia dados para UI (apenas campos que mudaram desde o último tick).
            -- GetHoursTime() é chamado aqui de propósito: precisa rodar todo tick
            -- pelos seus efeitos colaterais (mensagens de início/fim de assalto).
            pushHudDiff(hudCache, {
                life = playerData.life,
                shield = playerData.armour,
                stamina = playerData.stamina,
                thirst = PlayerState.thirst,
                hunger = PlayerState.hunger,
                assault = GetHoursTime() or false,
                street = streetName,
                isSpeaking = playerData.isSpeaking,
                time = timeString,
                user_id = PlayerState.user_id,
                gems = PlayerState.gems,
                city = 'Norte',
            })

            -- armory é tabela aninhada: envia só quando a assinatura muda
            local armorySig = armorySignature(weaponData)
            if armorySig ~= lastArmorySig then
                lastArmorySig = armorySig
                SendNUIMessage({ action = 'set:hud', data = { armory = weaponData } })
            end
        end
        
        -- -- Atualiza visibilidade
        -- SendNUIMessage({ action = 'set:visible', data = PlayerState.showHud })

        UpdateRadarVisibility()
        SetBigmapActive(false, false)
        
        Wait(idle)
    end
end)

CreateThread(function()
    while true do
        -- Só notifica o servidor quando a rua realmente muda (antes era a cada 5s, sempre).
        if actualStreetName and actualStreetName ~= lastSentStreet then
            lastSentStreet = actualStreetName
            TriggerServerEvent('updatePlayerStreet', actualStreetName)
        end

         -- Gerencia menu de pausa
        if IsPauseMenuActive() then
            if not pauseBreak then
                SendNUIMessage({ action = 'set:visible', data = false })
                pauseBreak = true
            end
        elseif pauseBreak and PlayerState.showHud and not IsHudLocked() then
            SendNUIMessage({ action = 'set:visible', data = true })
            pauseBreak = false
        end
        
        Wait(5000)
    end
end)

-- =====================================================
-- EVENTOS DE COMUNICAÇÃO OTIMIZADOS
-- =====================================================

RegisterNetEvent("hud:Capuz", function()
    PlayerState.toggleCapuz = not PlayerState.toggleCapuz

    local ped = PlayerPedId()
    if PlayerState.toggleCapuz then
        SetPedComponentVariation(ped,1,69,2,2)
    else 
        SetPedComponentVariation(ped,1,0,0,2)
    end

    SendNUIMessage({
        action = 'set:capuz',
        data = PlayerState.toggleCapuz
    })
end)

RegisterNetEvent("hud:Voip", function(number)
    local value = math.min(number or 0, 4)
    SendNUIMessage({ 
        action = 'set:hud', 
        data = { voip_level = value } 
    })
end)

RegisterNetEvent("hud:Radio", function(frequency)
    CommState.frequency = frequency or 'OFF'
    SendNUIMessage({ 
        action = 'set:hud', 
        data = { radio = CommState.frequency } 
    })
end)

RegisterNetEvent("pma-voice:setTalkingMode", function(mode)
    CommState.talking = mode or 2
    SendNUIMessage({ 
        action = 'set:hud', 
        data = { isSpeaking = CommState.talking } 
    })
end)

RegisterNetEvent("pma-voice:radioActive", function(state)
    local source = GetPlayerServerId(PlayerId())

    if not state then 
        return removeUserTalking(source)
    end

    local playerData = getPlayerData(source)
    addUserTalking(source, playerData.id, playerData.name)
end)

RegisterNetEvent("pma-voice:setTalkingOnRadio", function(source, state)
    if not state then 
        return removeUserTalking(source)
    end

    local playerData = getPlayerData(source)
    addUserTalking(source, playerData.id, playerData.name)
end)

function getPlayerData(source)
    local cachedData = RadioFrequency.cachedData[source]

    local playerData = cachedData or vSERVER.getUserName(source)
    if not cachedData then
        RadioFrequency.cachedData[source] = playerData
    end

    return playerData
end

function addUserTalking(source, id, name)
    RadioFrequency.talking[#RadioFrequency.talking + 1] = {
        source = source,
        id = id,
        name = name
    }

    SendNUIMessage({
        action = "radio:users",
        data = RadioFrequency.talking
    })
end

function removeUserTalking(source)
    for index, data in pairs(RadioFrequency.talking) do
        if data.source == source then
            RadioFrequency.talking[index] = nil
        end
    end

    SendNUIMessage({
        action = "radio:users",
        data = RadioFrequency.talking
    })
end

-- =====================================================
-- EVENTOS DE CONTROLE DA HUD
-- =====================================================

local hudControlEvents = {
    "character:hudActived",
    "hudActived", 
    "hud:Active"
}

for _, eventName in ipairs(hudControlEvents) do
    RegisterNetEvent(eventName, function(bool)
        if bool == nil then bool = true end
        -- Guarda a intenção da cidade mesmo travado: é ela que volta a valer quando a
        -- partida solta a trava.
        PlayerState.showHud = bool
        ApplyHudVisibility()
    end)
end

--- Segura a HUD escondida enquanto a partida durar.
---
--- O dono sai do `GetInvokingResource()` — quem chama não precisa (nem consegue) provar
--- quem é, e aceitar um nome livre deixaria um resource soltar a trava de outro.
---@return boolean
exports('LockHud', function()
    local owner = GetInvokingResource() or "desconhecido"
    if HudLocks[owner] then return true end

    HudLocks[owner] = true
    ApplyHudVisibility()
    return true
end)

---@return boolean
exports('UnlockHud', function()
    local owner = GetInvokingResource() or "desconhecido"
    if not HudLocks[owner] then return false end

    HudLocks[owner] = nil
    ApplyHudVisibility()
    return true
end)

---@return boolean
exports('IsHudLocked', function()
    return IsHudLocked()
end)

--- Resource dono da trava caiu (restart, erro, stop): a trava dele morre junto.
--- Sem isto, um `restart europa_events` no meio de uma partida deixaria a cidade inteira
--- sem HUD até alguém reiniciar ESTE resource.
AddEventHandler('onClientResourceStop', function(resourceName)
    if not HudLocks[resourceName] then return end

    HudLocks[resourceName] = nil
    ApplyHudVisibility()
end)

--- Estado atual da HUD, para quem precisa DEVOLVER como estava.
---
--- Quem esconde a HUD para abrir um painel a ligava de volta com `hud:Active(true)`, e
--- isso ligava para todo mundo — inclusive para quem joga com ela desligada de propósito,
--- que via a HUD reaparecer toda vez que fechasse qualquer menu. Com isto o chamador lê
--- antes, esconde, e devolve o valor que leu.
---@return boolean
exports('IsHudEnabled', function()
    return PlayerState.showHud == true
end)

--- REAFIRMAÇÃO PERIÓDICA da visibilidade.
---
--- `set:visible` é uma mensagem só, mandada na hora em que o estado muda: se a NUI perder
--- essa mensagem — recarga da página, um `SetNuiFocus` no meio, dois resources mandando o
--- contrário no mesmo frame — ela fica presa no estado errado e nada a corrige, porque não
--- há uma segunda mensagem prevista. Era isso a HUD que "buga" depois de o jogador clicar
--- em algo, e reaparece ligada em quem a tinha desligado.
---
--- Aqui o Lua é a fonte da verdade e repete o que sabe a cada 5s. A NUI ignora a repetição
--- quando já está no estado pedido, então o custo é uma mensagem por 5s.
CreateThread(function()
    while true do
        Wait(5000)

        --- Criação/seleção de personagem tem laço próprio logo acima, que já manda `false`
        --- a cada 500ms. Repetir aqui só brigaria com ele.
        if not (LocalPlayer.state.onCreate or LocalPlayer.state.editChar or LocalPlayer.state.onSpawnSelect) then
            -- Passa pelo `ApplyHudVisibility` e não pelo `showHud` cru: era esta repetição
            -- que devolvia a HUD da cidade para dentro da partida a cada 5 segundos,
            -- desfazendo o `hud:Active false` que o evento tinha pedido.
            ApplyHudVisibility()
        end
    end
end)

-- =====================================================
-- COMANDOS OTIMIZADOS
-- =====================================================

--- Menu de opções da HUD. Mesma trava do chat (ver `openChat` no `chat.lua`): o menu mora
--- na MESMA página da HUD, então com ela escondida — partida, criação de personagem — o
--- comando abria foco de NUI com NADA visível para clicar, e o jogador ficava com o cursor
--- preso sem ter o que fechar.
local function OpenHudMenu()
    if HudVisible == false then return end

    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'menu:hud',
        data = true
    })
end

RegisterCommand("hud", OpenHudMenu)
RegisterCommand("menu", OpenHudMenu)

local seatbeltThread = false
function SeatbeltVehicleLeaveThread()
    if seatbeltThread then return end
    seatbeltThread = true

    CreateThread(function()
        while PlayerState.seatbelt == true do
            DisableControlAction(0, 75, true)
    
            Wait(10)
        end

        seatbeltThread = false
    end)
end

RegisterCommand("setBelt", function()
    local ped = GetCachedPed()
    if IsPedInAnyVehicle(ped) and not IsPedOnAnyBike(ped) then
        PlayerState.seatbelt = not PlayerState.seatbelt
        if PlayerState.seatbelt then
            TriggerEvent("sounds:Private", "belt", 0.5)
            SeatbeltVehicleLeaveThread()
        else
            TriggerEvent("sounds:Private", "unbelt", 0.5)
        end
    end
end)

-- =====================================================
-- FUNÇÕES EXPORTADAS OTIMIZADAS
-- =====================================================
function DS.setZone(typeZone)
    SendNUIMessage({ 
        action = 'set:hud', 
        data = { zone = typeZone } 
    })
end

--- Tempo maximo que o servidor fica a espera da resposta do jogador.
local FORMULARY_TIMEOUT_MS = 120000

--- Espera entre olhadelas ao pedido. Era `Wait(1000)`, e por isso TODA resposta chegava ao
--- chamador com ate um segundo de atraso -- numa corrente de formularios era o que se via
--- como "demora a abrir o proximo".
local FORMULARY_POLL_MS = 50

--- O formulário NÃO responde ao `HudVisible`, ao contrário do chat, do `/hud` e dos alertas.
---
--- Aqueles três moram na página da HUD e somem com ela, então tomar foco de NUI com ela
--- escondida deixava o cursor preso numa tela vazia. Este não: o `FormularyProvider` está
--- FORA da div de visibilidade do layout, então o modal desenha na mesma — e a trava só
--- fazia com que todo `vRP.Formulary` devolvesse `nil` em silêncio para quem joga com a HUD
--- desligada ou está numa partida. Era o mesmo sintoma do bug que ela devia evitar: o
--- formulário simplesmente não abria.
function DS.Formulary(title, description, inputs)
    local request = { done = false, response = nil }
    ActiveFormulary = request

    SetNuiFocus(true, true)

    CreateThread(function()
        while not request.done do
            DisableAllControlActions(0)
            Wait(0)
        end
    end)

    SendNUIMessage({
        action = 'formularyRequest',
        data = {
            title = title,
            description = description,
            inputs = inputs
        }
    })

    local deadline = GetGameTimer() + FORMULARY_TIMEOUT_MS

    while not request.done and GetGameTimer() < deadline do
        Wait(FORMULARY_POLL_MS)
    end

    -- Solta o laco que desativa os controlos, tenha havido resposta ou timeout.
    request.done = true

    -- Se outro formulario ja tomou o lugar deste (duas chamadas ao mesmo jogador), o dono do
    -- foco e do ecra e ele: este nao lhe mexe em nada.
    local stillMine = ActiveFormulary == nil or ActiveFormulary == request

    if ActiveFormulary == request then
        -- So chega aqui por timeout: no caminho normal quem resolveu ja limpou o pedido.
        -- A NUI continua a mostrar o formulario e ninguem lhe disse para fechar.
        ActiveFormulary = nil
        SendNUIMessage({ action = 'formularyDismiss' })
    end

    if stillMine then
        SetNuiFocus(false, false)
    end

    -- `false` e o fechar sem responder; `nil` e o timeout. Os dois valem `nil` para quem chamou.
    if type(request.response) ~= 'table' then return nil end

    return request.response
end

exports('formulary', DS.Formulary)
exports('setZone', DS.setZone)
exports('syncNeeds', syncNeedsVariables)

-- =====================================================
-- INICIALIZAÇÃO DO MINIMAPA
-- =====================================================
CreateThread(function()
    -- Configura minimapa circular
    RequestStreamedTextureDict("circleminimap", false)
    while not HasStreamedTextureDictLoaded("circleminimap") do
        Wait(100)
    end

    SetMinimapClipType(1)
    AddReplaceTexture("platform:/textures/graphics", "radarmasksm", "circleminimap", "radarmasksm")
    
    -- Posições otimizadas do minimapa
    local positions = {
        minimap = { -0.0045, 0.002 - 0.025, 0.150, 0.188888 },
        minimap_mask = { 0.020, 0.030 - 0.025, 0.111, 0.159 },
        minimap_blur = { -0.03, 0.022 - 0.040, 0.266, 0.200 }
    }
    
    for component, pos in pairs(positions) do
        SetMinimapComponentPosition(component, "L", "B", pos[1], pos[2], pos[3], pos[4])
    end

    SetBigmapActive(true, false)
    Wait(50)
    SetBigmapActive(false, false)
    DisplayRadar(false)
    
    UpdateRadarVisibility()
    
    -- Sync global variables with PlayerState after initialization
    Wait(1000) -- Wait a bit for everything to be properly loaded
    syncNeedsVariables()

    Wait(1000 * 20)

    SendNUIMessage({
        action = "refetch:minimapDimensions",
        data = {}
    })
end)

-- Fome e sede

if hudConfig.hungerThirst then
    local function ensureNeedsInitialized()
        if not hunger then hunger = 100 end
        if not thirst then thirst = 100 end
    end

    local updateFoods = GetGameTimer()
    CreateThread(function()
        ensureNeedsInitialized()
        
        while true do
            local ped = PlayerPedId()
            if GetGameTimer() >= updateFoods and GetEntityHealth(ped) > 101 and not LocalPlayer.state.Farming and not LocalPlayer.state.SafeZone then
                updateFoods = GetGameTimer() + 5 * 60 * 1000

                thirst -= 4
                hunger -= 3

                if thirst <= 10 then
                    TriggerEvent('Notify', 'aviso', 'Você está ficando com sede', 5000)
                end
                if hunger <= 10 then
                    TriggerEvent('Notify', 'aviso', 'Você está ficando com fome', 5000)
                end

                vRPserver.FoodsServer()
            end

            Wait(30000)
        end
    end)

    local needsDamage = function()
        local applyDamage = function(damage, ped, health)
            SetFlash(0, 0, 500, 1000, 500)
            ApplyDamageToPed(ped, damage, false)

            local health = GetEntityHealth(ped)

            if health <= 0 then
                TriggerEvent('gameEventTriggered', 'CEventNetworkEntityDamage', {
                    PlayerPedId(),
                    PlayerPedId(),
                    1,
                    1,
                    1,
                    1,
                    'STATUS_DAMAGE'
                })
            end
        end
        local checkDamage = function(value, ped, health)
            if LocalPlayer.state.inPvp then return end
            if not value then return end
            
            if value == 0 then
                applyDamage(1, ped, health)
            elseif value < 20 then
                SetFlash(0, 0, 500, 1000, 500)
            end
        end
        while true do
            local ped = PlayerPedId()
            local health = GetEntityHealth(ped)
            if health > 0 then
                checkDamage(hunger, ped, health)
                checkDamage(thirst, ped, health)
            end
            Wait(10000)
        end
    end    

    CreateThread(function()
        ensureNeedsInitialized()
        needsDamage()
    end)
end

-- Sem o `Wait(500)` que havia aqui: ele existia para "limpar" o `ForceClosed` global, e
-- era ele que criava a janela em que o cancelamento passava despercebido ao laco.
RegisterNuiCallback('formularyClosed', function(_, cb)
    SetNuiFocus(false, false)
    ResolveFormulary(false)
    cb({})
end)

AddEventHandler("hud:safeZoneStatus", function(payload)
    SendNUIMessage({
        action = 'set:safezone',
        data = payload
    })
end)

AddEventHandler("hud:notifyBlock", function(payload)
    SendNUIMessage({
        action = 'set:notify:block',
        data = payload
    })
end)

AddEventHandler("hud:setRobbery", function(payload)
    SendNUIMessage({
        action = 'set:robbery',
        data = payload
    })
end)

function updateTouretteStatus(status)
    SetNuiFocus(status, status)

    SendNUIMessage({
        action = 'set:tourret:visible',
        data = status
    })
end

RegisterNetEvent("hud:openTourette", function()
    updateTouretteStatus(true)
end)

RegisterNetEvent("hud:closeTourette", function()
    updateTouretteStatus(false)
end)

RegisterNUICallback("close:tourret", function(_, cb)
    updateTouretteStatus(false)
    
    cb(true)
end)

RegisterNUICallback("get:colors", function (data,cb)
    cb({
        ["--primaryColor"] = "#F50C0C",
        ["--secondaryColor"] = "#DB0B0B",
        ["--thirdyColor"] = "#DB0B0B",
    })
end)

AddEventHandler("hud:setHappyHour", function(payload)
    SendNUIMessage({ action = 'set:happyhour', data = payload })
end)
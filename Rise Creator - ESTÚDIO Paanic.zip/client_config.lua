local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
func = Tunnel.getInterface("nation_creator")
fclient = {}
Tunnel.bindInterface("nation_creator", fclient)

nation_skinshop = true -- deixe true caso use o script nation_skinshop

creatorCoords = vec3(-528.9,-226.64,36.63)
creatorHeading = 212.6


spawnCoords = vec3(-1038.3,-2738.54,13.72)
spawnHeading = 328.82


maxHealth = 400 -- vida máxima do player

---------------------------------------------------------------------------
-----------------------ANIMAÇÃO DE PARADO---------------------------
---------------------------------------------------------------------------

function LoadAnim(dict)
    while not HasAnimDictLoaded(dict) do
        RequestAnimDict(dict)
        Wait(10)
    end
end

function freezeAnim(dict, anim, flag, keep)
    if not keep then
        ClearPedTasks(PlayerPedId())
    end
    LoadAnim(dict)
    TaskPlayAnim(PlayerPedId(), dict, anim, 2.0, 2.0, -1, flag or 1, 0, false, false, false)
    RemoveAnimDict(dict)
end

local multiCharAnim = {
    dict = "anim@amb@nightclub@dancers@crowddance_facedj@hi_intensity",
    anim = "hi_dance_facedj_09_v1_male^5",
}

function playMultiCharAnim()
    freezeAnim(multiCharAnim.dict, multiCharAnim.anim, 1)
end

function clearMultiCharAnim()
    ClearPedTasks(PlayerPedId())
end



---------------------------------------------------------------------------
-----------------------ROUPAAS PADRÕES PARA A CRIAÇÃO----------------------
---------------------------------------------------------------------------

resetCloths = function()
    local clothes = {
        [GetHashKey("mp_m_freemode_01")] = {
            ["gender"] = "male",
            ["bodyArmors"] = { 0, 0, 0 },
            ["torsos"] = { 15, 0, 2 },
            ["accessories"] = { -1, 0, 2 },
            ["hats"] = { -1,0 },
            ["masks"] = { 0,0,0 },
            ["undershirts"] = { 15, 0, 2 },
            ["shoes"] = { 34, 0, 2 },
            ["bracelets"] = { -1,0 },
            ["tops"] = { 15, 0, 2 },
            ["bags"] = { 0,0,0 },
            ["ears"] = { -1,0 },
            ["decals"] = { 0,0,0 },
            ["legs"] = { 61, 0, 2 },
            ["watches"] = { -1,0 },
            ["glasses"] = { -1,0 },
        },

        [GetHashKey("mp_f_freemode_01")] = {
            ["gender"] = "female",
            ["bodyArmors"] = { 0, 0, 0 },
            ["torsos"] = { 15, 0, 2 },
            ["accessories"] = { -1, 0, 2 },
            ["hats"] = { -1,0 },
            ["masks"] = { 0,0,0 },
            ["undershirts"] = { 14, 0, 2 },
            ["shoes"] = { 35, 0, 2 },
            ["bracelets"] = { -1,0 },
            ["tops"] = { 15, 0, 2 },
            ["bags"] = { 0,0,0 },
            ["ears"] = { -1,0 },
            ["decals"] = { 0,0,0 },
            ["legs"] = { 15, 0, 2 },
            ["watches"] = { -1,0 },
            ["glasses"] = { -1,0 },
        },
    }
    local model = GetEntityModel(PlayerPedId())
    setClothes(clothes[model] or {})
end




---------------------------------------------------------------------------
-----------------------ROUPAAS SETADAS APÓS CRIAR--------------------------
---------------------------------------------------------------------------

setCloths = function()
    local clothes = {
        [GetHashKey("mp_m_freemode_01")] = {
            ["gender"] = "male",
            ["bodyArmors"] = { 0, 0, 0 },
            ["torsos"] = { 0, 0, 2 },
            ["accessories"] = { -1, 0, 2 },
            ["hats"] = { -1,0 },
            ["masks"] = { 0,0,2 },
            ["undershirts"] = { 15, 0, 2 },
            ["shoes"] = { 1, 0, 2 },
            ["bracelets"] = { -1,0 },
            ["tops"] = { 16, 2, 2 },
            ["bags"] = { 0,0,0 },
            ["ears"] = { -1,0 },
            ["decals"] = { 0,0,0 },
            ["legs"] = { 4, 1, 2 },
            ["watches"] = { -1,0 },
            ["glasses"] = { -1,0 },
        },

        [GetHashKey("mp_f_freemode_01")] = {
            ["gender"] = "female",
            ["bodyArmors"] = { 0, 0, 0 },
            ["torsos"] = { 14, 0, 2 },
            ["accessories"] = { 0, 0, 2 },
            ["hats"] = { -1,0 },
            ["masks"] = { 0,0,0 },
            ["undershirts"] = { 6, 0, 2 },
            ["shoes"] = { 49, 0, 2 },
            ["bracelets"] = { -1,0 },
            ["tops"] = { 338, 7, 2 },
            ["bags"] = { 0,0,0 },
            ["ears"] = { -1,0 },
            ["decals"] = { 0,0,0 },
            ["legs"] = { 112, 0, 2 },
            ["watches"] = { -1,0 },
            ["glasses"] = { -1,0 },
        },
    }
    local model = GetEntityModel(PlayerPedId())
    setClothes(clothes[model] or {})
end




---------------------------------------------------------------------------
-----------------------CÂMERAS--------------------------
---------------------------------------------------------------------------

local cameras = {
    body = { coords = vec3(0.0, 2.5, 0.8), point = vec3(0.0,0.0,0.0), f = function() freezeAnim("move_f@multiplayer", "idle") end }, 
    head = { coords = vec3(0.0, 0.5, 0.7), point = vec3(0.0,0.0,0.67), f = function() freezeAnim("mp_sleep", "bind_pose_180", 1, true) end },
    eye = { coords = vec3(0.0, 0.27, 0.7), point = vec3(0.0,0.0,0.7), f = function() freezeAnim("mp_sleep", "bind_pose_180", 1, true) end },
    mouth = { coords = vec3(0.0, 0.27, 0.63), point = vec3(0.0,0.0,0.63), f = function() freezeAnim("mp_sleep", "bind_pose_180", 1, true) end },
    chest = { coords = vec3(0.0, 1.2, 0.4), point = vec3(0.0,0.0,0.2), f = function() freezeAnim("mp_sleep", "bind_pose_180", 1, true) end }, 
}

function createCamera()
    local ped = PlayerPedId()
    local groundCam = CreateCam("DEFAULT_SCRIPTED_CAMERA")
    AttachCamToEntity(groundCam, ped, 0.0, -2.0, 0.0)
    SetCamActive(groundCam, true)
    RenderScriptCams(true, false, 1, true, true)
    activeCam = "body"
    local cam = cameras[activeCam]
    local coord = GetOffsetFromEntityInWorldCoords(ped, cam.coords)
    fixedCam = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", coord, 0, 0, 0, 50.0)
    -- Aponte a fixedCam para o ponto especificado em relação ao personagem
    local pointCoords = GetOffsetFromEntityInWorldCoords(ped, cam.point)
    PointCamAtCoord(fixedCam, pointCoords)
    SetCamActive(fixedCam, true)
    SetCamActiveWithInterp(fixedCam, groundCam, 1000, true, true)
    if cam.f then cam.f() end
    CreateThread(function()
        Wait(1000)
        DestroyCam(groundCam)
    end)
end

componentCams = {
    ["chestHair"] = "chest",
    ["hair"] = "head",
    ["facialHair"] = "head",
    ["blush"] = "head",
    ["lipstick"] = "mouth",
    ["makeup"] = "head",
}

local activeCam

function interpCamera(cameraName)
    if cameras[cameraName] then
        if cameraName == activeCam then return end
        activeCam = cameraName
        local ped = PlayerPedId()
        SetEntityHeading(ped, creatorHeading)
        local cam = cameras[cameraName]
        local coord = GetOffsetFromEntityInWorldCoords(ped,cam.coords)
        local tempCam = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", coord, 0,0,0, 50.0)
        local pointCoords = GetOffsetFromEntityInWorldCoords(ped,cam.point)
        SetCamActive(tempCam, true)
        SetCamActiveWithInterp(tempCam, fixedCam, 600, true, true)
        PointCamAtCoord(tempCam, pointCoords)
        if cam.f then cam.f() end
        CreateThread(function()
            Wait(600)
            DestroyCam(fixedCam)
            fixedCam = tempCam
        end)
    end
end



function createCamera()
    local ped = PlayerPedId()
    local groundCam = CreateCam("DEFAULT_SCRIPTED_CAMERA")
    AttachCamToEntity(groundCam, ped, 0.0, -2.0, 0.0)
    SetCamActive(groundCam, true)
    RenderScriptCams(true, false, 1, true, true)
    activeCam = "body"
    local cam = cameras[activeCam]
    local coord = GetOffsetFromEntityInWorldCoords(ped,cam.coords)
    fixedCam = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", coord, 0,0,0, 50.0)
    local pointCoords = GetOffsetFromEntityInWorldCoords(ped,cam.point)
    PointCamAtCoord(fixedCam, pointCoords)
    SetCamActive(fixedCam, true)
    SetCamActiveWithInterp(fixedCam, groundCam, 1000, true, true)
    if cam.f then cam.f() end
    CreateThread(function()
        Wait(1000)
        DestroyCam(groundCam)
    end)
end






local NAME_MIN_LEN = 2
local NAME_MAX_LEN = 16
local NAME_LETTERS_ONLY = "^[%aÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇáàâãäéèêëíìîïóòôõöúùûüçÑñ]+$"

local function normalizeIdentityName(value)
    if type(value) ~= "string" then return nil end
    local trimmed = value:match("^%s*(.-)%s*$")
    if not trimmed or trimmed == "" then return nil end
    return trimmed
end

local function isValidIdentityName(value)
    local normalized = normalizeIdentityName(value)
    if not normalized or normalized:find(" ") then return false end
    if not normalized:match(NAME_LETTERS_ONLY) then return false end
    local length = utf8 and utf8.len(normalized) or #normalized
    return length >= NAME_MIN_LEN and length <= NAME_MAX_LEN
end

getPopupText = function(data) -- TEXTO QUE VAI APARECER NO POPUP NA HORA DE FINALIZAR A CRIAÇÃO
    name = normalizeIdentityName(data.name)
    lastName = normalizeIdentityName(data.lastName)
    age = math.floor(tonumber(data.age or 0) or 0)

    if not isValidIdentityName(name) then
        return false, "nome inválido (apenas letras, sem números, espaços, emojis ou símbolos)"
    end

    if not isValidIdentityName(lastName) then
        return false, "sobrenome inválido (apenas letras, sem números, espaços, emojis ou símbolos)"
    end

    if not age or age < 16 or age > 70 then
        return false , "idade inválida"
    end
    return true, "deseja criar o personagem "..name.." "..lastName.." ("..age.." anos) ?"
end

function teleport(ply,x, y, z)
    if type(x) == "vector3" then
        x,y,z = table.unpack(x)
    end
    FreezeEntityPosition(ply, true)
    SetEntityCoords(ply, x + 0.0001, y + 0.0001, z + 0.0001, 1, 0, 0, 1)
    local timer = 10
    while not HasCollisionLoadedAroundEntity(ply) and timer > 0 do
        FreezeEntityPosition(ply, true)
        SetEntityCoords(ply, x + 0.0001, y + 0.0001, z + 0.0001, 1, 0, 0, 1)
        RequestCollisionAtCoord(x, y, z)
        Wait(500)
        timer = timer - 1
    end
    SetEntityCoords(ply, x + 0.0001, y + 0.0001, z + 0.0001, 1, 0, 0, 1)
    FreezeEntityPosition(ply, false)
    Wait(1000)
end

function initCreator()
    TriggerEvent("hud:Active",false)
    TriggerEvent("nation_barbershop:stop")
    func.changeSession(GetPlayerServerId(PlayerId()))
    loadingPlayer(true)
    local ped = PlayerPedId()
    DoScreenFadeOut(500)
    Wait(500)
    teleport(ped, creatorCoords)
    SetEntityHeading(ped, creatorHeading)
    setGender("male")
    SetEntityHealth(ped, GetPedMaxHealth(ped))
    resetCloths()
    SetFacialIdleAnimOverride(PlayerPedId(), "pose_normal_1", 0)
    Wait(1000)
    DoScreenFadeIn(1000)
end

function finishCreator()
    changeClothes() -- nation_skinshop
    local ped = PlayerPedId()
    DoScreenFadeOut(500)
    Wait(1500)
    cutScene()
    teleport(ped, spawnCoords)
    SetEntityHeading(ped, spawnHeading)
    FreezeEntityPosition(ped, false)
    SetEntityHealth(ped, GetPedMaxHealth(ped))
    func._updateLogin()
    func.changeSession(0)
    Wait(1000)
    DoScreenFadeIn(1000)
    TriggerEvent("hud:Active",true)
end

RegisterNetEvent("nation_creator:finishClothes")
AddEventHandler("nation_creator:finishClothes", function()
    clothesFinished = true
    Wait(5000)
    clothesFinished = false
end)

function changeClothes()
    if nation_skinshop and GetResourceState("nation_skinshop") == "started" then
        TriggerEvent("nation_skinshop:toggleMenu", "nation_creator")
        while not clothesFinished do
            Wait(500)
        end
    else
        setCloths()
    end
end

function setGender(gender)    
    local model = "mp_m_freemode_01"
    if gender == "female" then
        model = "mp_f_freemode_01"
    elseif gender ~= "male" then
        model = gender
    end
    RequestModel(model)
    while not HasModelLoaded(model) do
        Citizen.Wait(10)   
    end
    local ped = PlayerPedId()
    local currentHealth, currentMaxHealth, currentArmour = GetEntityHealth(ped), GetPedMaxHealth(ped), GetPedArmour(ped)
    local weapons = vRP.getWeapons() or {}
    print(PlayerId(), model)
    SetPlayerModel(PlayerId(), model)
    ped = PlayerPedId()
    SetPedMaxHealth(ped, maxHealth) -- setar vida maxima 
    SetEntityHealth(ped, currentHealth)
    SetPedArmour(ped, currentArmour)
    vRP.giveWeapons(weapons,true)
    resetCloths()
    if gender == "male" then
        SetPedHeadBlendData(ped, 21, 0, 0, 21, 0, 0, 0.8, 0.8, 0.0, false)
    else
        SetPedHeadBlendData(ped, 21, 0, 0, 21, 0, 0, 0.2, 0.2, 0.0, false)
    end
end

function fclient.spawnPlayer(firstspawn)
    TriggerEvent("hud:Active",true)
    loginSpawn(not firstspawn)
end

function loadingPlayer(stats)
    TriggerEvent("hud:Active",false)
    local ped = PlayerPedId()
    SetEntityInvincible(ped,false)
    SetEntityVisible(ped,stats)
    FreezeEntityPosition(ped,not stats)
end

function parseFloat(num)
    local n = tonumber(num..".0")
    if not n then n = tonumber(num) or num end
    return n
end

function f(num)
    local n = parseFloat(string.format("%.2f", tostring(num)))
    return n
end


local overlays = {
    [GetHashKey("mp_m_freemode_01")] = {
        { collection = 'mpbeach_overlays', overlay = 'FM_Hair_Fuzz' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_002' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_003' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_004' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_005' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_006' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_007' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_008' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_009' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_013' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_002' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_011' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_012' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_014' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_015' },
        { collection = 'multiplayer_overlays', overlay = 'NGBea_M_Hair_000' },
        { collection = 'multiplayer_overlays', overlay = 'NGBea_M_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NGBus_M_Hair_000' },
        { collection = 'multiplayer_overlays', overlay = 'NGBus_M_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NGHip_M_Hair_000' },
        { collection = 'multiplayer_overlays', overlay = 'NGHip_M_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NGInd_M_Hair_000' },
        { collection = 'mplowrider_overlays', overlay = 'LR_M_Hair_000' },
        { collection = 'mplowrider_overlays', overlay = 'LR_M_Hair_001' },
        { collection = 'mplowrider_overlays', overlay = 'LR_M_Hair_002' },
        { collection = 'mplowrider_overlays', overlay = 'LR_M_Hair_003' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_M_Hair_004' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_M_Hair_005' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_M_Hair_006' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_000_M' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_001_M' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_002_M' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_003_M' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_004_M' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_005_M' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_002' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_003' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_004' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_005' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_006' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_007' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_008' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_009' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_013' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_002' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_011' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_012' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_014' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_015' },
        { collection = 'multiplayer_overlays', overlay = 'NGBea_M_Hair_000' },
        { collection = 'multiplayer_overlays', overlay = 'NGBea_M_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NGBus_M_Hair_000' },
        { collection = 'multiplayer_overlays', overlay = 'NGBus_M_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NGHip_M_Hair_000' },
        { collection = 'multiplayer_overlays', overlay = 'NGHip_M_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NGInd_M_Hair_000' },
        { collection = 'mplowrider_overlays', overlay = 'LR_M_Hair_000' },
        { collection = 'mplowrider_overlays', overlay = 'LR_M_Hair_001' },
        { collection = 'mplowrider_overlays', overlay = 'LR_M_Hair_002' },
        { collection = 'mplowrider_overlays', overlay = 'LR_M_Hair_003' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_M_Hair_004' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_M_Hair_005' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_M_Hair_006' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_000_M' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_001_M' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_002_M' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_003_M' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_004_M' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_005_M' },
        { collection = 'mpgunrunning_overlays', overlay = 'MP_Gunrunning_Hair_M_000_M'},
        { collection = 'mpgunrunning_overlays', overlay = 'MP_Gunrunning_Hair_M_001_M'}
    },

    [GetHashKey("mp_f_freemode_01")] = {
        { collection = 'mpbeach_overlays', overlay = 'FM_Hair_Fuzz' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_002' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_003' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_004' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_005' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_006' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_007' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_008' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_009' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_010' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_011' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_012' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_013' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_014' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_015' },
        { collection = 'multiplayer_overlays', overlay = 'NGBea_F_Hair_000' },
        { collection = 'multiplayer_overlays', overlay = 'NGBea_F_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_007' },
        { collection = 'multiplayer_overlays', overlay = 'NGBus_F_Hair_000' },
        { collection = 'multiplayer_overlays', overlay = 'NGBus_F_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NGBea_F_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NGHip_F_Hair_000' },
        { collection = 'multiplayer_overlays', overlay = 'NGInd_F_Hair_000' },
        { collection = 'mplowrider_overlays', overlay = 'LR_F_Hair_000' },
        { collection = 'mplowrider_overlays', overlay = 'LR_F_Hair_001' },
        { collection = 'mplowrider_overlays', overlay = 'LR_F_Hair_002' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_F_Hair_003' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_F_Hair_003' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_F_Hair_004' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_F_Hair_006' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_000_F' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_001_F' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_002_F' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_003_F' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_003' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_006_F' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_004_F' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_002' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_003' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_004' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_005' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_006' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_007' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_008' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_009' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_010' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_011' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_012' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_013' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_014' },
        { collection = 'multiplayer_overlays', overlay = 'NG_M_Hair_015' },
        { collection = 'multiplayer_overlays', overlay = 'NGBea_F_Hair_000' },
        { collection = 'multiplayer_overlays', overlay = 'NGBea_F_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_007' },
        { collection = 'multiplayer_overlays', overlay = 'NGBus_F_Hair_000' },
        { collection = 'multiplayer_overlays', overlay = 'NGBus_F_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NGBea_F_Hair_001' },
        { collection = 'multiplayer_overlays', overlay = 'NGHip_F_Hair_000' },
        { collection = 'multiplayer_overlays', overlay = 'NGInd_F_Hair_000' },
        { collection = 'mplowrider_overlays', overlay = 'LR_F_Hair_000' },
        { collection = 'mplowrider_overlays', overlay = 'LR_F_Hair_001' },
        { collection = 'mplowrider_overlays', overlay = 'LR_F_Hair_002' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_F_Hair_003' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_F_Hair_003' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_F_Hair_004' },
        { collection = 'mplowrider2_overlays', overlay = 'LR_F_Hair_006' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_000_F' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_001_F' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_002_F' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_003_F' },
        { collection = 'multiplayer_overlays', overlay = 'NG_F_Hair_003' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_006_F' },
        { collection = 'mpbiker_overlays', overlay = 'MP_Biker_Hair_004_F' },
        { collection = 'mpgunrunning_overlays', overlay = 'MP_Gunrunning_Hair_F_000_F' },
        { collection = 'mpgunrunning_overlays', overlay = 'MP_Gunrunning_Hair_F_001_F' }
    }
}

function getOverlays()
    local model = GetEntityModel(PlayerPedId())
    return overlays[model] or {}
end

function getOverlayByIndex(index)
    return getOverlays()[index]
end




----------------------------------------------------------------------------
-------------------------- MULTI CHAR --------------------------------------
----------------------------------------------------------------------------



RegisterNetEvent("spawn:setupChars")
AddEventHandler("spawn:setupChars", function()
    Wait(1000)
    while not loaded do
        Wait(1000)
    end
    openMultiChar()
end)

function initMultiChar()
    func.changeSession(GetPlayerServerId(PlayerId()))
    loadingPlayer(false)
    TriggerEvent("nation_barbershop:stop")
    local ped = PlayerPedId()
    DoScreenFadeOut(500)
    Wait(500)
    FreezeEntityPosition(ped, true)
    local x,y,z = table.unpack(creatorCoords)
    RequestCollisionAtCoord(x, y, z)
    teleport(ped, x,y,z-0.9)
    SetEntityHeading(ped, creatorHeading)
    Wait(1000)
    setCameraCoords("body")
    DoScreenFadeIn(1000)
end


function leaveMultiChar(keepSession)
    clearCharMugshot()
    clearMultiCharAnim()
    local ped = PlayerPedId()
    DoScreenFadeOut(500)
    Wait(1500)
    FreezeEntityPosition(ped, false)
    if not keepSession then
        func.changeSession(0)
    end
    deleteCam()
    Wait(1000)
end


local charMugshotHandle = nil

function sendCharMugshot()
    CreateThread(function()
        if charMugshotHandle then
            UnregisterPedheadshot(charMugshotHandle)
            charMugshotHandle = nil
        end

        Wait(300)

        local ped = PlayerPedId()
        if not IsEntityVisible(ped) then
            SendNUIMessage({ action = "setCharMugshot", txd = false })
            return
        end

        local mugshot = RegisterPedheadshotTransparent(ped)
        local timeout = GetGameTimer() + 3000

        while not IsPedheadshotReady(mugshot) and GetGameTimer() < timeout do
            Wait(50)
        end

        if mugshot and mugshot ~= 0 and IsPedheadshotReady(mugshot) then
            local txd = GetPedheadshotTxdString(mugshot)
            charMugshotHandle = mugshot
            SendNUIMessage({ action = "setCharMugshot", txd = txd })
            Wait(1000)
            UnregisterPedheadshot(mugshot)
            if charMugshotHandle == mugshot then
                charMugshotHandle = nil
            end
        elseif mugshot and mugshot ~= 0 then
            UnregisterPedheadshot(mugshot)
            SendNUIMessage({ action = "setCharMugshot", txd = false })
        end
    end)
end

function clearCharMugshot()
    if charMugshotHandle then
        UnregisterPedheadshot(charMugshotHandle)
        charMugshotHandle = nil
    end
    SendNUIMessage({ action = "setCharMugshot", txd = false })
end

function selectCharacter(info)
    if info then
        setPlayerChar(info.char)
        if info.clothes and next(info.clothes) ~= nil then
            setClothing(info.clothes)
        else
            resetCloths()
        end
        TriggerEvent("nation_barbershop:init", info.char)
    end
    loadingPlayer(info ~= nil)
    if info then
        sendCharMugshot()
        playMultiCharAnim()
    else
        clearCharMugshot()
        clearMultiCharAnim()
    end
end


function playChar(info)
    if not info then return end
    func._playChar(info)
    toggleMultiChar()
end

function createChar()
    if not func.tryCreateChar() then return end
    if inMultiChar then
        inMultiChar = false
        SetNuiFocus(false, false)
        SendNUIMessage({ action = "hideMultiChar" })
        leaveMultiChar(true)
    end
    startCreator()
end

function getDeleteCharMessage(info)
    if info and info.char then
        return false, "Para deletar seu personagem abra um ticket!"
    end
    return false, "error"
end

function tryDeleteChar(info)
    local success, message = func.tryDeleteChar(info)
    return success, message
end


----------------------------------------------------------------------------
----------------------------------------------------------------------------
----------------------------------------------------------------------------


function setClothing(data)
	local ped = PlayerPedId()
    if not data then
        return resetCloths()
    end
    if not data.pants then
        return setClothes(data)
    end

    local components = { mask = 1, arms = 3, pants = 4, shoes = 6, backpack = 5, accessory = 7, tshirt = 8, vest = 9, decals = 10, torso = 11 }
    local props = { hat = 0, glass = 1, ear = 2, watch = 6, bracelet = 7 }
    for comp, i in pairs(components) do
        SetPedComponentVariation(ped,i,data[comp].item,data[comp].texture,2)
    end
    for prop, i in pairs(props) do
        if data[prop].item > 0 then
            SetPedPropIndex(ped,i,data[prop].item,data[prop].texture,2)
        else
            ClearPedProp(ped,i)
        end
    end
end

fclient.setClothing = setClothing






------------------------- CUT SCENE -----------------------------

local CUTSCENE_NAME = "gen9_mig_int"
local CUTSCENE_COORDS = vec3(519.67, 169.28, 99.36)
local CUTSCENE_PLAYER_SLOT = "MP_1"
local CUTSCENE_EXTRA_SLOTS = { "MP_2", "MP_3", "MP_4" }
local CUTSCENE_AUDIO_URL = "https://r2.riseroleplay.com.br/sounds/audiocreator.ogg"
local CUTSCENE_AUDIO_SOUND = nil
local CUTSCENE_AUDIO_VOLUME = 0.5
local inCutscene = false

local function playCutsceneAudio()
    if CUTSCENE_AUDIO_URL and CUTSCENE_AUDIO_URL ~= "" then
        TriggerEvent("sounds:Url", CUTSCENE_AUDIO_URL, CUTSCENE_AUDIO_VOLUME)
        return
    end

    if CUTSCENE_AUDIO_SOUND and CUTSCENE_AUDIO_SOUND ~= "" then
        TriggerEvent("sounds:source", CUTSCENE_AUDIO_SOUND, CUTSCENE_AUDIO_VOLUME)
    end
end

local function stopCutsceneAudio()
    if CUTSCENE_AUDIO_URL and CUTSCENE_AUDIO_URL ~= "" then
        TriggerEvent("sounds:stop", nil, CUTSCENE_AUDIO_URL)
        return
    end

    if CUTSCENE_AUDIO_SOUND and CUTSCENE_AUDIO_SOUND ~= "" then
        TriggerEvent("sounds:stop", CUTSCENE_AUDIO_SOUND)
    end
end

local function registerPlayerForCutscene(ped)
    local model = GetEntityModel(ped)

    SetCutsceneEntityStreamingFlags(CUTSCENE_PLAYER_SLOT, 0, 1)
    RegisterEntityForCutscene(ped, CUTSCENE_PLAYER_SLOT, 0, model, 64)

    for i = 1, #CUTSCENE_EXTRA_SLOTS do
        local slot = CUTSCENE_EXTRA_SLOTS[i]
        SetCutsceneEntityStreamingFlags(slot, 0, 1)
        RegisterEntityForCutscene(0, slot, 3, model, 0)
    end
end

local function applyPlayerAppearanceToCutscene(ped)
    SetCutscenePedComponentVariationFromPed(CUTSCENE_PLAYER_SLOT, ped, GetEntityModel(ped))
end

local function waitForCutsceneEntity(slot, timeoutMs)
    local deadline = GetGameTimer() + timeoutMs
    while not DoesCutsceneEntityExist(slot, 0) do
        Wait(10)
        if GetGameTimer() > deadline then
            return false
        end
    end
    return true
end

function cutScene()
    local plyrId = PlayerPedId()
    inCutscene = true

    FreezeEntityPosition(plyrId, true)

    RequestCutscene(CUTSCENE_NAME, 8)

    local timeout = GetGameTimer() + 15000
    while not HasCutsceneLoaded() do
        Wait(10)
        if GetGameTimer() > timeout then
            print("[nation_creator] Falha ao carregar cutscene: " .. CUTSCENE_NAME)
            stopCutsceneAudio()
            inCutscene = false
            FreezeEntityPosition(plyrId, false)
            return
        end
    end

    FinalizeHeadBlend(plyrId)

    local playerClone = ClonePed_2(plyrId, 0.0, false, true, 1)
    SetBlockingOfNonTemporaryEvents(playerClone, true)
    SetEntityVisible(playerClone, false, false)
    SetEntityInvincible(playerClone, true)
    SetEntityCollision(playerClone, false, false)
    FreezeEntityPosition(playerClone, true)
    SetPedHelmet(playerClone, false)
    RemovePedHelmet(playerClone, true)

    local model = GetEntityModel(plyrId)
    local assetsTimeout = GetGameTimer() + 5000
    while not CanRequestAssetsForCutsceneEntity(CUTSCENE_PLAYER_SLOT, model) do
        Wait(10)
        if GetGameTimer() > assetsTimeout then
            break
        end
    end

    registerPlayerForCutscene(plyrId)
    SetEntityVisible(plyrId, false, false)

    NewLoadSceneStartSphere(CUTSCENE_COORDS.x, CUTSCENE_COORDS.y, CUTSCENE_COORDS.z, 1000.0, 0)

    playCutsceneAudio()

    CreateThread(setWeather)
    StartCutscene(4)

    CreateThread(function()
        while IsCutsceneActive() do
            SetPlayerControl(PlayerId(), true, false)
            Wait(1)
        end
    end)

    if waitForCutsceneEntity(CUTSCENE_PLAYER_SLOT, 5000) then
        applyPlayerAppearanceToCutscene(plyrId)
        ClonePedToTarget(playerClone, plyrId)
        SetEntityVisible(plyrId, true, false)
    else
        print("[nation_creator] Entidade da cutscene nao encontrada: " .. CUTSCENE_PLAYER_SLOT)
        SetEntityVisible(plyrId, true, false)
    end

    DeleteEntity(playerClone)

    DoScreenFadeIn(1000)

    timeout = GetGameTimer() + 120000
    while IsCutsceneActive() and not HasCutsceneFinished() do
        Wait(100)
        if GetGameTimer() > timeout then
            break
        end
    end

    DoScreenFadeOut(500)
    Wait(500)
    stopCutsceneAudio()
    StopCutsceneImmediately()
    RemoveCutscene()
    NewLoadSceneStop()
    FreezeEntityPosition(plyrId, false)
    inCutscene = false
end


function setWeather()
    while inCutscene do
        SetWeatherTypeNow("EXTRASUNNY")
        NetworkOverrideClockTime(12,0,0)
        Wait(0)
    end
end

function IsMale(ped)
	if IsPedModel(ped, 'mp_m_freemode_01') then
		return true
	else
		return false
	end
end



------------------------------------------------------------------



------------------------- LOGIN-----------------------------

spawns = {
    { name = "Garagem Praça", coords = {56.91,-873.89,30.45,65.2} },
    { name = "Garagem Sandy Shores", coords = {318.1,2623.98,44.47,268.35} },
    { name = "Garagem Paleto", coords = {-760.53,5583.51,36.7,90.71} },
    { name = "Departamento Policial", coords = {-1649.6,248.35,62.39,206.93} },
    { name = "Hospital Sul", coords = {-2736.58,-82.07,18.59,14.18} },
}


function fclient.setPlayerLastCoords(coords)
    if lastCoords then return end
    lastCoords = coords
    table.insert(spawns, { name = "Última Localização", coords = lastCoords })
end





local cam = nil
function loginSpawn(status)
    TriggerEvent("hud:Active",true)
    TriggerEvent("hookSelector",status)
end


function changeLoginCam(x,y,z)
	local ped = PlayerPedId()
    local myCoords = GetEntityCoords(ped)
    if #(myCoords - vec3(x,y,z)) < 3 then return end
    changingSpawnCam = true
    SetEntityCoordsNoOffset(ped, x,y,z)
    local coord = GetOffsetFromEntityInWorldCoords(ped,0.0,0.0,200.0)
    local tempCam = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", coord, 0,0,0, 50.0)
    local tempCamPoint = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", coord, 0,0,0, 50.0)
    local camPoint = CreateCamWithParams("DEFAULT_SCRIPTED_CAMERA", myCoords.x, myCoords.y, myCoords.z+200, 0,0,0, 50.0)
    PointCamAtCoord(tempCam, coord)
    PointCamAtCoord(camPoint, coord)
    PointCamAtCoord(tempCamPoint, x,y,z)
    SetCamActive(camPoint, true)
    SetCamActiveWithInterp(camPoint, cam, 500, true, true)
    Wait(500)
    DestroyCam(cam)
    cam = camPoint
    SetCamActive(tempCam, true)
    SetCamActiveWithInterp(tempCam, cam, 1000, true, true)
    Wait(1000)
    DestroyCam(cam)
    cam = tempCam
    SetCamActive(tempCamPoint, true)
    SetCamActiveWithInterp(tempCamPoint, cam, 500, true, true)
    Wait(500)
    DestroyCam(cam)
    cam = tempCamPoint
    changingSpawnCam = false
end

function GetHeadBlendData(ped)
    local p = {Citizen.InvokeNative(0x2746BD9D88C5C5D0, ped, Citizen.PointerValueIntInitialized(0), Citizen.PointerValueIntInitialized(0), Citizen.PointerValueIntInitialized(0), Citizen.PointerValueIntInitialized(0), Citizen.PointerValueIntInitialized(0), Citizen.PointerValueIntInitialized(0), Citizen.PointerValueFloatInitialized(0), Citizen.PointerValueFloatInitialized(0), Citizen.PointerValueFloatInitialized(0))}
    local headBlendData = {
        shapeFirst = p[1],
        shapeSecond = p[2],
        shapeThird = p[3],
        skinFirst = p[4],
        skinSecond = p[5],
        skinThird = p[6],
        shapeMix = p[7],
        skinMix = p[8],
        thirdMix = p[9]
    }
    return headBlendData
end

RegisterNetEvent("login:Spawn")
AddEventHandler("login:Spawn",loginSpawn)


RegisterNetEvent("nation_creator:forceSaveChar")
AddEventHandler("nation_creator:forceSaveChar", function(user_id)
    local char = getPlayerChar(PlayerPedId())
    func._saveChar(false, false, false, char, user_id)
    TriggerEvent("nation_barbershop:init", char)
end)


CreateThread(function()
    loadingPlayer(false) -- comentar caso nao queira que o player fique invisível quando spawna
    while true do
        if inMultiChar or inMenu or inLoginMenu or spawnned then
            break
        end
        local ped = PlayerPedId()
        SetEntityInvincible(ped,false)
        SetEntityVisible(ped,true)
        FreezeEntityPosition(ped,true)
        Wait(10)
    end
end)



--------------------- BARBERSHOP OLD --------------------------


function fclient.setOldChar(char, custom, gender, user_id)
    local data = char
    setGender(gender)
    local ped = PlayerPedId()
    SetPedHeadBlendData(ped, tonumber(data.fathersID), tonumber(data.mothersID), 0, tonumber(data.skinColor), 0, 0, f(data.shapeMix), 0, 0, false)
    SetPedEyeColor(ped, data.eyesColor)
    -- Sobrancelha
    SetPedFaceFeature(ped, 6, tonumber(data.eyebrowsHeight))
    SetPedFaceFeature(ped, 7, tonumber(data.eyebrowsWidth))
    -- -- Nariz
    SetPedFaceFeature(ped, 0, tonumber(data.noseWidth))
    SetPedFaceFeature(ped, 1, tonumber(data.noseHeight))
    SetPedFaceFeature(ped, 2, tonumber(data.noseLength))
    SetPedFaceFeature(ped, 3, tonumber(data.noseBridge))
    SetPedFaceFeature(ped, 4, tonumber(data.noseTip))
    -- SetPedFaceFeature(ped, 5, data.noseShift)
    -- Bochechas
    SetPedFaceFeature(ped, 8, tonumber(data.cheekboneHeight))
    SetPedFaceFeature(ped, 9, tonumber(data.cheekboneWidth))
    SetPedFaceFeature(ped, 10, tonumber(data.cheeksWidth))
    -- -- Boca/Mandibula
    SetPedFaceFeature(ped, 12, tonumber(data.lips))
    SetPedFaceFeature(ped, 13, tonumber(data.jawWidth))
    SetPedFaceFeature(ped, 14, tonumber(data.jawHeight))
    -- -- Queixo
    SetPedFaceFeature(ped, 15, tonumber(data.chinLength))
    SetPedFaceFeature(ped, 16, tonumber(data.chinPosition))
    SetPedFaceFeature(ped, 17, tonumber(data.chinWidth))
    SetPedFaceFeature(ped, 18, tonumber(data.chinShape))
    -- -- Pescoço
    SetPedFaceFeature(ped, 19, tonumber(data.neckWidth))
    -- sobrancelhas
    SetPedHeadOverlay(ped, 2, data.eyebrowsModel, 0.99)
    SetPedHeadOverlayColor(ped, 2, 1, data.eyebrowsColor, data.eyebrowsColor)
    -- Cabelo
    SetPedComponentVariation(ped, 2, tonumber(data.hairModel), 0, 0)
    SetPedHairColor(ped, tonumber(data.firstHairColor), tonumber(data.secondHairColor))
    -- -- Barba
    SetPedHeadOverlay(ped, 1, tonumber(data.beardModel), 0.99)
    SetPedHeadOverlayColor(ped, 1, 1, tonumber(data.beardColor), tonumber(data.beardColor))
    -- -- Pelo Corporal
    SetPedHeadOverlay(ped, 10, tonumber(data.chestModel), 0.99)
    SetPedHeadOverlayColor(ped, 10, 1, tonumber(data.chestColor), tonumber(data.chestColor))
    -- -- Maquiagem
    SetPedHeadOverlay(ped, 4, tonumber(data.makeupModel), 0.99)
    SetPedHeadOverlayColor(ped, 4, 0, 0, 0)
    -- -- Blush
    SetPedHeadOverlay(ped, 5, tonumber(data.blushModel), 0.99)
    SetPedHeadOverlayColor(ped, 5, 2, tonumber(data.blushColor), tonumber(data.blushColor))
    -- -- Battom
    SetPedHeadOverlay(ped, 8, tonumber(data.lipstickModel), 0.99)
    SetPedHeadOverlayColor(ped, 8, 2, tonumber(data.lipstickColor), tonumber(data.lipstickColor))
    -- Manchas
    SetPedHeadOverlay(ped, 0, tonumber(data.blemishesModel), 0.99)
    SetPedHeadOverlayColor(ped, 0, 0, 0, 0)
    -- Envelhecimento
    SetPedHeadOverlay(ped, 3, tonumber(data.ageingModel), 0.99)
    SetPedHeadOverlayColor(ped, 3, 0, 0, 0)
    -- Aspecto
    SetPedHeadOverlay(ped, 6, tonumber(data.complexionModel), 0.99)
    SetPedHeadOverlayColor(ped, 6, 0, 0, 0)
    -- Pele
    SetPedHeadOverlay(ped, 7, tonumber(data.sundamageModel), 0.99)
    SetPedHeadOverlayColor(ped, 7, 0, 0, 0)
    -- Sardas
    SetPedHeadOverlay(ped, 9, tonumber(data.frecklesModel), 0.99)
    SetPedHeadOverlayColor(ped, 9, 0, 0, 0)
    func._setPlayerTattoos(user_id)
    setClothing(custom)
    TriggerEvent("nation_creator:forceSaveChar", user_id)
    return getPlayerChar(ped)
end
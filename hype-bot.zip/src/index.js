const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Collection, MessageFlags } = require('discord.js');
const { loadConfig } = require('./config');
const { createDiscordAgent } = require('./discord-http');
const { handleButton } = require('./handlers/buttons');
const { handleModal } = require('./handlers/modals');

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
  rest: { agent: createDiscordAgent() },
});

client.commands = new Collection();
const commandsPath = path.join(__dirname, 'commands');
for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'))) {
  const command = require(path.join(commandsPath, file));
  client.commands.set(command.data.name, command);
}

client.once('clientReady', () => {
  console.log(`Bot online como ${client.user.tag}`);
});

client.on('interactionCreate', async (interaction) => {
  // config é recarregado a cada interação para refletir mudanças feitas com /config
  const config = loadConfig();
  const ctx = { config, client };

  try {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      await command.execute(interaction, ctx);
      return;
    }

    if (interaction.isButton()) {
      await handleButton(interaction, ctx);
      return;
    }

    if (interaction.isModalSubmit()) {
      await handleModal(interaction, ctx);
      return;
    }
  } catch (error) {
    console.error(error);
    const errorPayload = { content: 'Ocorreu um erro ao processar essa ação.', flags: MessageFlags.Ephemeral };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(errorPayload).catch(() => {});
    } else {
      await interaction.reply(errorPayload).catch(() => {});
    }
  }
});

const config = loadConfig();
client.login(config.token);

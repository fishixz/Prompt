const { PermissionFlagsBits } = require('discord.js');

function isAdmin(interaction, config) {
  const userId = interaction.user.id;
  if (Array.isArray(config.adminIds) && config.adminIds.includes(userId)) return true;
  if (interaction.member && interaction.member.permissions?.has(PermissionFlagsBits.Administrator)) {
    return true;
  }
  return false;
}

module.exports = { isAdmin };

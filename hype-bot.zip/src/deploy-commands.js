const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { loadConfig } = require('./config');
const { createDiscordAgent, getProxyUrl, isDiscordConnectTimeout } = require('./discord-http');

const config = loadConfig();

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'))) {
  const command = require(path.join(commandsPath, file));
  commands.push(command.data.toJSON());
}

const rest = new REST({ agent: createDiscordAgent() }).setToken(config.token);

(async () => {
  try {
    console.log(`Registrando ${commands.length} comando(s)...`);

    if (config.guildId) {
      // Registro no servidor (instantâneo, ideal para testes)
      await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), {
        body: commands,
      });
      console.log('Comandos registrados no servidor com sucesso.');
    } else {
      // Registro global (pode levar até 1h para propagar)
      await rest.put(Routes.applicationCommands(config.clientId), { body: commands });
      console.log('Comandos registrados globalmente com sucesso.');
    }
  } catch (error) {
    if (isDiscordConnectTimeout(error)) {
      console.error('Nao foi possivel conectar em https://discord.com:443 para registrar os slash commands.');
      console.error('Isso normalmente significa bloqueio de rede, firewall, VPN ou proxy nao configurado.');
      if (getProxyUrl()) {
        console.error(`Proxy detectado: ${getProxyUrl()}`);
      } else {
        console.error('Se voce usa proxy, defina DISCORD_PROXY_URL, HTTPS_PROXY ou HTTP_PROXY e rode npm run deploy novamente.');
      }
      console.error('Se a rede for apenas lenta, aumente o tempo com DISCORD_CONNECT_TIMEOUT_MS=60000.');
    }
    console.error(error);
  }
})();

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const ALLOWLIST_FILE = path.join(DATA_DIR, 'allowlist.json');
const CODIGUIM_FILE = path.join(DATA_DIR, 'codiguim.json');

function ensure(file, fallback) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(fallback, null, 2));
}

function readJson(file, fallback) {
  ensure(file, fallback);
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}

// ---- Allowlist ----
function getAllowlistData() {
  return readJson(ALLOWLIST_FILE, { submissions: {} });
}

function saveAllowlistData(data) {
  writeJson(ALLOWLIST_FILE, data);
}

function createSubmission(userId, answers) {
  const data = getAllowlistData();
  const id = `${userId}-${Date.now()}`;
  data.submissions[id] = {
    id,
    userId,
    answers,
    status: 'pendente',
    createdAt: new Date().toISOString(),
    reviewedBy: null,
    reviewedAt: null,
  };
  saveAllowlistData(data);
  return data.submissions[id];
}

function getSubmission(id) {
  const data = getAllowlistData();
  return data.submissions[id] || null;
}

function updateSubmission(id, patch) {
  const data = getAllowlistData();
  if (!data.submissions[id]) return null;
  data.submissions[id] = { ...data.submissions[id], ...patch };
  saveAllowlistData(data);
  return data.submissions[id];
}

function hasPendingSubmission(userId) {
  const data = getAllowlistData();
  return Object.values(data.submissions).some(
    (s) => s.userId === userId && s.status === 'pendente'
  );
}

// ---- Codiguim ----
function getCodiguimData() {
  return readJson(CODIGUIM_FILE, { redemptions: [] });
}

function saveCodiguimData(data) {
  writeJson(CODIGUIM_FILE, data);
}

function addRedemption(userId, code, partnerName) {
  const data = getCodiguimData();
  const entry = {
    userId,
    code,
    partnerName,
    createdAt: new Date().toISOString(),
  };
  data.redemptions.push(entry);
  saveCodiguimData(data);
  return entry;
}

function hasRedeemedCode(userId, code) {
  const data = getCodiguimData();
  return data.redemptions.some(
    (r) => r.userId === userId && r.code.toUpperCase() === code.toUpperCase()
  );
}

module.exports = {
  createSubmission,
  getSubmission,
  updateSubmission,
  hasPendingSubmission,
  addRedemption,
  hasRedeemedCode,
};

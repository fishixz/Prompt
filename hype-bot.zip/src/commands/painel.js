const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { buildAllowlistPanel, buildCodiguimPanel } = require('../panels');
const { isAdmin } = require('../permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('painel')
    .setDescription('Envia um painel do bot neste canal')
    .addSubcommand((sub) =>
      sub.setName('allowlist').setDescription('Envia o painel de Hypelist (Allowlist)')
    )
    .addSubcommand((sub) =>
      sub.setName('codiguim').setDescription('Envia o painel de Codiguim')
    ),

  async execute(interaction, ctx) {
    if (!isAdmin(interaction, ctx.config)) {
      return interaction.reply({
        content: 'Você não tem permissão para usar este comando.',
        flags: MessageFlags.Ephemeral,
      });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'allowlist') {
      const { container, attachment } = buildAllowlistPanel(ctx.config);
      await interaction.channel.send({
        components: [container],
        files: [attachment],
        flags: MessageFlags.IsComponentsV2,
      });
      return interaction.reply({ content: 'Painel de Allowlist enviado.', flags: MessageFlags.Ephemeral });
    }

    if (sub === 'codiguim') {
      const { container, attachment } = buildCodiguimPanel(ctx.config);
      await interaction.channel.send({
        components: [container],
        files: [attachment],
        flags: MessageFlags.IsComponentsV2,
      });
      return interaction.reply({ content: 'Painel de Codiguim enviado.', flags: MessageFlags.Ephemeral });
    }
  },
};

const { SlashCommandBuilder, MessageFlags, ChannelType } = require('discord.js');
const { saveConfig } = require('../config');
const { isAdmin } = require('../permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('config')
    .setDescription('Configura o bot (apenas administradores do bot)')
    .addSubcommand((sub) =>
      sub
        .setName('add-admin')
        .setDescription('Dá permissão de administrador do bot a um usuário')
        .addUserOption((opt) => opt.setName('usuario').setDescription('Usuário').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('remove-admin')
        .setDescription('Remove a permissão de administrador do bot de um usuário')
        .addUserOption((opt) => opt.setName('usuario').setDescription('Usuário').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('set-review-channel')
        .setDescription('Define o canal onde as solicitações de allowlist são revisadas')
        .addChannelOption((opt) =>
          opt
            .setName('canal')
            .setDescription('Canal de revisão')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('set-log-channel')
        .setDescription('Define o canal onde os resultados (aprovado/recusado, codiguim) são logados')
        .addChannelOption((opt) =>
          opt
            .setName('canal')
            .setDescription('Canal de log')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('toggle-allowlist')
        .setDescription('Abre ou fecha o formulário de Allowlist')
        .addBooleanOption((opt) =>
          opt.setName('aberto').setDescription('true para abrir, false para fechar').setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('toggle-codiguim')
        .setDescription('Ativa ou desativa o painel de Codiguim')
        .addBooleanOption((opt) =>
          opt.setName('ativo').setDescription('true para ativar, false para desativar').setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('add-code')
        .setDescription('Adiciona um codiguim válido')
        .addStringOption((opt) => opt.setName('codigo').setDescription('Código').setRequired(true))
        .addStringOption((opt) =>
          opt.setName('parceiro').setDescription('Nome do parceiro/criador').setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('remove-code')
        .setDescription('Remove um codiguim')
        .addStringOption((opt) => opt.setName('codigo').setDescription('Código').setRequired(true))
    ),

  async execute(interaction, ctx) {
    if (!isAdmin(interaction, ctx.config)) {
      return interaction.reply({
        content: 'Você não tem permissão para usar este comando.',
        flags: MessageFlags.Ephemeral,
      });
    }

    const sub = interaction.options.getSubcommand();
    const config = ctx.config;

    if (sub === 'add-admin') {
      const user = interaction.options.getUser('usuario');
      if (!config.adminIds.includes(user.id)) config.adminIds.push(user.id);
      saveConfig(config);
      return interaction.reply({ content: `${user} agora é administrador do bot.`, flags: MessageFlags.Ephemeral });
    }

    if (sub === 'remove-admin') {
      const user = interaction.options.getUser('usuario');
      config.adminIds = config.adminIds.filter((id) => id !== user.id);
      saveConfig(config);
      return interaction.reply({ content: `${user} não é mais administrador do bot.`, flags: MessageFlags.Ephemeral });
    }

    if (sub === 'set-review-channel') {
      const channel = interaction.options.getChannel('canal');
      config.reviewChannelId = channel.id;
      saveConfig(config);
      return interaction.reply({ content: `Canal de revisão definido para ${channel}.`, flags: MessageFlags.Ephemeral });
    }

    if (sub === 'set-log-channel') {
      const channel = interaction.options.getChannel('canal');
      config.logChannelId = channel.id;
      saveConfig(config);
      return interaction.reply({ content: `Canal de log definido para ${channel}.`, flags: MessageFlags.Ephemeral });
    }

    if (sub === 'toggle-allowlist') {
      config.allowlistOpen = interaction.options.getBoolean('aberto');
      saveConfig(config);
      return interaction.reply({
        content: `Allowlist agora está ${config.allowlistOpen ? 'aberta' : 'fechada'}. Reenvie o painel (/painel allowlist) para atualizar o botão.`,
        flags: MessageFlags.Ephemeral,
      });
    }

    if (sub === 'toggle-codiguim') {
      config.codiguimOpen = interaction.options.getBoolean('ativo');
      saveConfig(config);
      return interaction.reply({
        content: `Codiguim agora está ${config.codiguimOpen ? 'ativado' : 'desativado'}. Reenvie o painel (/painel codiguim) para atualizar o botão.`,
        flags: MessageFlags.Ephemeral,
      });
    }

    if (sub === 'add-code') {
      const codigo = interaction.options.getString('codigo').toUpperCase();
      const parceiro = interaction.options.getString('parceiro');
      config.codiguinCodes[codigo] = parceiro;
      saveConfig(config);
      return interaction.reply({ content: `Código **${codigo}** registrado para ${parceiro}.`, flags: MessageFlags.Ephemeral });
    }

    if (sub === 'remove-code') {
      const codigo = interaction.options.getString('codigo').toUpperCase();
      delete config.codiguinCodes[codigo];
      saveConfig(config);
      return interaction.reply({ content: `Código **${codigo}** removido.`, flags: MessageFlags.Ephemeral });
    }
  },
};

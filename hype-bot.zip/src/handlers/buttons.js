const {
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
} = require('discord.js');
const { isAdmin } = require('../permissions');
const store = require('../store');
const { buildReviewPanel, statusLabel } = require('../panels');

async function handleButton(interaction, ctx) {
  const { customId } = interaction;

  if (customId === 'allowlist_start') return startAllowlist(interaction, ctx);
  if (customId === 'codiguim_apply') return startCodiguim(interaction, ctx);
  if (customId.startsWith('allowlist_approve_')) return reviewAllowlist(interaction, ctx, 'aprovado');
  if (customId.startsWith('allowlist_reject_')) return reviewAllowlist(interaction, ctx, 'recusado');
}

async function startAllowlist(interaction, ctx) {
  const { config } = ctx;

  if (!config.allowlistOpen) {
    return interaction.reply({
      content: 'O formulário de Allowlist está fechado temporariamente.',
      flags: MessageFlags.Ephemeral,
    });
  }

  if (store.hasPendingSubmission(interaction.user.id)) {
    return interaction.reply({
      content: 'Você já possui uma solicitação de Allowlist pendente de análise.',
      flags: MessageFlags.Ephemeral,
    });
  }

  const questions = config.allowlistQuestions.slice(0, 5);
  const modal = new ModalBuilder().setCustomId('allowlist_modal').setTitle('Formulário de Allowlist');

  questions.forEach((question, i) => {
    const input = new TextInputBuilder()
      .setCustomId(`q_${i}`)
      .setLabel(question.slice(0, 45))
      .setStyle(question.length > 60 ? TextInputStyle.Paragraph : TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(1000);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
  });

  await interaction.showModal(modal);
}

async function startCodiguim(interaction, ctx) {
  const { config } = ctx;

  if (config.codiguimOpen === false) {
    return interaction.reply({
      content: 'O sistema de Codiguim está desativado temporariamente.',
      flags: MessageFlags.Ephemeral,
    });
  }

  const modal = new ModalBuilder().setCustomId('codiguim_modal').setTitle('Aplicar Codiguim');

  const input = new TextInputBuilder()
    .setCustomId('codigo')
    .setLabel('Digite o código do parceiro/criador')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(50);

  modal.addComponents(new ActionRowBuilder().addComponents(input));

  await interaction.showModal(modal);
}

async function reviewAllowlist(interaction, ctx, decision) {
  const { config, client } = ctx;

  if (!isAdmin(interaction, config)) {
    return interaction.reply({
      content: 'Você não tem permissão para revisar solicitações de Allowlist.',
      flags: MessageFlags.Ephemeral,
    });
  }

  const submissionId = interaction.customId.replace(
    decision === 'aprovado' ? 'allowlist_approve_' : 'allowlist_reject_',
    ''
  );

  const submission = store.getSubmission(submissionId);
  if (!submission) {
    return interaction.reply({ content: 'Solicitação não encontrada.', flags: MessageFlags.Ephemeral });
  }

  if (submission.status !== 'pendente') {
    return interaction.reply({
      content: `Esta solicitação já foi ${statusLabel(submission.status).split(' ')[1].toLowerCase()}.`,
      flags: MessageFlags.Ephemeral,
    });
  }

  const updated = store.updateSubmission(submissionId, {
    status: decision,
    reviewedBy: interaction.user.id,
    reviewedAt: new Date().toISOString(),
  });

  const container = buildReviewPanel(updated, interaction.member);
  await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 });

  // Notifica o candidato via DM
  try {
    const candidate = await client.users.fetch(submission.userId);
    if (decision === 'aprovado') {
      await candidate.send(
        `Sua solicitação de Allowlist foi **aprovada**! ✅ Seja bem-vindo(a) ao Hype Roleplay.`
      );
    } else {
      await candidate.send(
        `Sua solicitação de Allowlist foi **recusada**. ❌ Você pode entrar em contato com a Staff para mais informações.`
      );
    }
  } catch (err) {
    // usuário com DMs fechadas
  }

  // Loga o resultado
  if (config.logChannelId) {
    const logChannel = await client.channels.fetch(config.logChannelId).catch(() => null);
    if (logChannel) {
      const emoji = decision === 'aprovado' ? '🟢' : '🔴';
      await logChannel.send(
        `${emoji} <@${submission.userId}> (${submission.userId}) teve a Allowlist **${decision}** por <@${interaction.user.id}>.`
      );
    }
  }
}

module.exports = { handleButton };

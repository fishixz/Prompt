const { MessageFlags } = require('discord.js');
const store = require('../store');
const { buildReviewPanel } = require('../panels');

async function handleModal(interaction, ctx) {
  if (interaction.customId === 'allowlist_modal') return submitAllowlist(interaction, ctx);
  if (interaction.customId === 'codiguim_modal') return submitCodiguim(interaction, ctx);
}

async function submitAllowlist(interaction, ctx) {
  const { config, client } = ctx;
  const questions = config.allowlistQuestions.slice(0, 5);

  const answers = questions.map((question, i) => ({
    question,
    answer: interaction.fields.getTextInputValue(`q_${i}`),
  }));

  const submission = store.createSubmission(interaction.user.id, answers);

  await interaction.reply({
    content: 'Sua solicitação de Allowlist foi enviada com sucesso! Aguarde a análise da nossa equipe.',
    flags: MessageFlags.Ephemeral,
  });

  if (config.reviewChannelId) {
    const reviewChannel = await client.channels.fetch(config.reviewChannelId).catch(() => null);
    if (reviewChannel) {
      const container = buildReviewPanel(submission, interaction.member);
      await reviewChannel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
  }
}

async function submitCodiguim(interaction, ctx) {
  const { config, client } = ctx;
  const code = interaction.fields.getTextInputValue('codigo').trim().toUpperCase();

  const partnerName = config.codiguinCodes[code];

  if (!partnerName) {
    return interaction.reply({
      content: 'Código inválido. Verifique se digitou corretamente e tente novamente.',
      flags: MessageFlags.Ephemeral,
    });
  }

  if (store.hasRedeemedCode(interaction.user.id, code)) {
    return interaction.reply({
      content: 'Você já aplicou este código anteriormente.',
      flags: MessageFlags.Ephemeral,
    });
  }

  store.addRedemption(interaction.user.id, code, partnerName);

  await interaction.reply({
    content: `Código **${code}** aplicado com sucesso! Sua indicação foi vinculada a **${partnerName}**. ⭐`,
    flags: MessageFlags.Ephemeral,
  });

  if (config.logChannelId) {
    const logChannel = await client.channels.fetch(config.logChannelId).catch(() => null);
    if (logChannel) {
      await logChannel.send(
        `⭐ <@${interaction.user.id}> (${interaction.user.id}) aplicou o codiguim **${code}** (parceiro: ${partnerName}).`
      );
    }
  }
}

module.exports = { handleModal };

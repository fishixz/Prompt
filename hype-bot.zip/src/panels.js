const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
} = require('discord.js');

const PINK = 0xff1493;

function buildAllowlistPanel(config) {
  const container = new ContainerBuilder().setAccentColor(PINK);

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      '## Quer fazer parte do Hype Roleplay, mas ainda não possui Hypelist?'
    ),
    new TextDisplayBuilder().setContent(
      'Preencha o formulário de ingresso e dê o primeiro passo para iniciar sua jornada na cidade.'
    ),
    new TextDisplayBuilder().setContent(
      '**Clique no botão** abaixo para acessar o formulário e começar seu processo de entrada no servidor. ⭐'
    )
  );

  container.addMediaGalleryComponents(
    new MediaGalleryBuilder().addItems(
      new MediaGalleryItemBuilder().setURL('attachment://allowlist-banner.png')
    )
  );

  container.addSeparatorComponents(
    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
  );

  const statusEmoji = config.allowlistOpen ? '🟢' : '🔴';
  const statusText = config.allowlistOpen ? 'Aberto' : 'Fechado temporariamente';
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`Status do Formulário: ${statusText} ${statusEmoji}`)
  );

  const button = new ButtonBuilder()
    .setCustomId('allowlist_start')
    .setLabel('Iniciar Allowlist RP')
    .setStyle(ButtonStyle.Secondary)
    .setDisabled(!config.allowlistOpen);

  container.addActionRowComponents(new ActionRowBuilder().addComponents(button));

  const attachment = new AttachmentBuilder(
    require('path').join(__dirname, 'assets', 'allowlist-banner.png'),
    { name: 'allowlist-banner.png' }
  );

  return { container, attachment };
}

function buildCodiguimPanel(config) {
  const container = new ContainerBuilder().setAccentColor(PINK);

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent('## Aplicar Codiguim'),
    new TextDisplayBuilder().setContent('Possui um codiguim de um parceiro ou criador de conteúdo?'),
    new TextDisplayBuilder().setContent(
      'Clique no botão abaixo para aplicar seu código e vincular sua entrada ao parceiro responsável pela indicação.'
    ),
    new TextDisplayBuilder().setContent(
      '- Processo rápido e automático\n- Registro imediato da indicação\n- Apoie seu criador favorito'
    ),
    new TextDisplayBuilder().setContent(
      'Caso esteja enfrentando algum problema ou tenha dúvidas sobre o processo, entre em contato com nossa equipe de Staff.'
    )
  );

  container.addMediaGalleryComponents(
    new MediaGalleryBuilder().addItems(
      new MediaGalleryItemBuilder().setURL('attachment://codiguim-banner.png')
    )
  );

  container.addSeparatorComponents(
    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
  );

  const statusEmoji = config.codiguimOpen === false ? '🔴' : '🟢';
  const statusText = config.codiguimOpen === false ? 'Desativado temporariamente' : 'Ativado temporariamente';
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`Status do Codiguim: ${statusText} ${statusEmoji}`)
  );

  const button = new ButtonBuilder()
    .setCustomId('codiguim_apply')
    .setLabel('APLICAR CODIGUINHO')
    .setEmoji('⭐')
    .setStyle(ButtonStyle.Secondary)
    .setDisabled(config.codiguimOpen === false);

  container.addActionRowComponents(new ActionRowBuilder().addComponents(button));

  const attachment = new AttachmentBuilder(
    require('path').join(__dirname, 'assets', 'codiguim-banner.png'),
    { name: 'codiguim-banner.png' }
  );

  return { container, attachment };
}

function buildReviewPanel(submission, member) {
  const container = new ContainerBuilder().setAccentColor(PINK);

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent('## Nova solicitação de Allowlist'),
    new TextDisplayBuilder().setContent(`Candidato: <@${submission.userId}> (${submission.userId})`)
  );

  container.addSeparatorComponents(
    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
  );

  const answerLines = submission.answers
    .map((a) => `**${a.question}**\n${a.answer}`)
    .join('\n\n');
  container.addTextDisplayComponents(new TextDisplayBuilder().setContent(answerLines));

  container.addSeparatorComponents(
    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
  );

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`Status: ${statusLabel(submission.status)}`)
  );

  const approveBtn = new ButtonBuilder()
    .setCustomId(`allowlist_approve_${submission.id}`)
    .setLabel('Aprovar')
    .setStyle(ButtonStyle.Success)
    .setDisabled(submission.status !== 'pendente');

  const rejectBtn = new ButtonBuilder()
    .setCustomId(`allowlist_reject_${submission.id}`)
    .setLabel('Recusar')
    .setStyle(ButtonStyle.Danger)
    .setDisabled(submission.status !== 'pendente');

  container.addActionRowComponents(new ActionRowBuilder().addComponents(approveBtn, rejectBtn));

  return container;
}

function statusLabel(status) {
  if (status === 'aprovado') return '🟢 Aprovado';
  if (status === 'recusado') return '🔴 Recusado';
  return '🟡 Pendente';
}

module.exports = { buildAllowlistPanel, buildCodiguimPanel, buildReviewPanel, statusLabel, PINK };

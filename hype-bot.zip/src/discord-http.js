const { Agent, ProxyAgent } = require('undici');

function parseTimeout(value, fallback) {
  const parsed = Number.parseInt(value ?? '', 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function getProxyUrl() {
  return (
    process.env.DISCORD_PROXY_URL ||
    process.env.HTTPS_PROXY ||
    process.env.https_proxy ||
    process.env.HTTP_PROXY ||
    process.env.http_proxy ||
    null
  );
}

function createDiscordAgent() {
  const connectTimeout = parseTimeout(process.env.DISCORD_CONNECT_TIMEOUT_MS, 30_000);
  const proxyUrl = getProxyUrl();

  if (proxyUrl) {
    return new ProxyAgent({
      uri: proxyUrl,
      connect: { timeout: connectTimeout },
    });
  }

  return new Agent({
    connect: { timeout: connectTimeout },
  });
}

function isDiscordConnectTimeout(error) {
  return error?.code === 'UND_ERR_CONNECT_TIMEOUT' || error?.name === 'ConnectTimeoutError';
}

module.exports = {
  createDiscordAgent,
  getProxyUrl,
  isDiscordConnectTimeout,
};

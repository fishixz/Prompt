const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '..', 'config.json');

function loadConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    const examplePath = path.join(__dirname, '..', 'config.example.json');
    fs.copyFileSync(examplePath, CONFIG_PATH);
    console.log('config.json não existia, foi criado a partir de config.example.json. Edite-o com seus dados antes de rodar o bot novamente.');
    process.exit(0);
  }
  return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
}

function saveConfig(config) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8');
}

module.exports = { loadConfig, saveConfig, CONFIG_PATH };

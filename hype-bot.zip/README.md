# Hype Bot — Allowlist & Codiguim - BOSS COMMUNITY

Bot de Discord com os painéis de **Allowlist (Hypelist)** e **Codiguim** feitos com **Components V2**,
no mesmo estilo visual do painel de referência (título em negrito, banner, status e botão).

## O que ele faz

- `/painel allowlist` — posta o painel de Allowlist no canal (com o banner da imagem 3).
- `/painel codiguim` — posta o painel de Codiguim no canal (com o banner da imagem 4).
- Botão **Iniciar Allowlist RP** → abre um formulário (modal) com as perguntas configuradas →
  a resposta cai no canal de revisão com botões **Aprovar** / **Recusar**.
- Ao aprovar/recusar: a mensagem de revisão é atualizada, o resultado é logado no canal de log
  e o candidato recebe um aviso por DM.
- Botão **APLICAR CODIGUINHO** → abre um modal pedindo o código → valida contra a lista de
  códigos cadastrados, registra a indicação e loga no canal de log.
- `/config` → comando de administração para configurar tudo isso sem mexer no código.

## Instalação

1. Instale as dependências:
   ```bash
   npm install
   ```

2. Configure o bot:
   - Copie `config.example.json` para `config.json` (ou apenas rode `npm start` uma vez —
     ele cria o arquivo automaticamente e encerra para você editar).
   - Preencha:
     - `token`: o token do bot (Discord Developer Portal → Bot → Reset Token).
     - `clientId`: o ID da aplicação (Developer Portal → General Information).
     - `guildId`: o ID do seu servidor (ativa o Modo Desenvolvedor no Discord e clique com o
       botão direito no servidor → Copiar ID). Isso faz os comandos aparecerem instantaneamente,
       só nesse servidor. Deixe em branco para registrar globalmente (demora até 1h para propagar).
     - `adminIds`: lista de IDs de usuários que podem usar `/painel` e `/config` mesmo sem a
       permissão "Administrador" do servidor.

3. Registre os comandos de barra:
   ```bash
   npm run deploy
   ```

4. Inicie o bot:
   ```bash
   npm start
   ```

## Configurando pelo Discord (depois de já rodando)

Use `/config` (só quem está em `adminIds` ou tem permissão de Administrador consegue usar):

- `/config add-admin usuario:@alguém` — dá permissão de administrador do bot.
- `/config remove-admin usuario:@alguém` — remove essa permissão.
- `/config set-review-channel canal:#canal` — define onde as solicitações de allowlist chegam
  para aprovação/recusa.
- `/config set-log-channel canal:#canal` — define onde ficam os logs (resultado da allowlist e
  aplicações de codiguim).
- `/config toggle-allowlist aberto:true/false` — abre ou fecha o formulário (igual ao
  "Status do Formulário: Fechado temporariamente" da imagem de referência).
- `/config toggle-codiguim ativo:true/false` — ativa ou desativa o painel de codiguim.
- `/config add-code codigo:PARCEIRO1 parceiro:"Nome do parceiro"` — cadastra um código válido.
- `/config remove-code codigo:PARCEIRO1` — remove um código.

Depois de mudar `toggle-allowlist` ou `toggle-codiguim`, rode `/painel allowlist` ou
`/painel codiguim` de novo no canal para o botão atualizar (habilitado/desabilitado) e o
status mostrado no painel refletir a mudança.

## Editar as perguntas da Allowlist

As perguntas ficam em `config.json`, no campo `allowlistQuestions` (máximo 5, que é o limite de
campos de um modal do Discord). Edite o texto de cada pergunta como quiser e não precisa reiniciar
o bot — ele recarrega o `config.json` a cada interação.

## Estrutura do projeto

```
hype-bot/
├── config.example.json      # modelo de configuração
├── package.json
├── src/
│   ├── index.js              # inicializa o bot e roteia as interações
│   ├── deploy-commands.js    # registra os slash commands
│   ├── config.js             # carrega/salva o config.json
│   ├── store.js               # persiste solicitações de allowlist e resgates de codiguim
│   ├── permissions.js        # checa quem é admin do bot
│   ├── panels.js              # monta os painéis visuais (Components V2)
│   ├── commands/
│   │   ├── painel.js         # /painel allowlist | codiguim
│   │   └── config.js         # /config ...
│   ├── handlers/
│   │   ├── buttons.js        # cliques nos botões (iniciar, aprovar, recusar, aplicar código)
│   │   └── modals.js         # envio dos formulários
│   ├── assets/
│   │   ├── allowlist-banner.png
│   │   └── codiguim-banner.png
│   └── data/
│       ├── allowlist.json    # criado automaticamente (log de solicitações)
│       └── codiguim.json     # criado automaticamente (log de resgates)
```

## Requisitos

- Node.js 18 ou superior.
- `discord.js` v14.19+ (já fixado no `package.json`), pois Components V2 é um recurso recente
  da API do Discord.
- No Developer Portal, nenhum privileged intent é necessário para esse bot (ele não lê mensagens
  nem lista membros), só o escopo `bot` e `applications.commands` na hora de gerar o link de convite,
  com as permissões **Enviar Mensagens**, **Anexar Arquivos** e **Usar Comandos de Barra**.

## Observações importantes

- O `token` do bot fica só no `config.json` local — nunca compartilhe esse arquivo nem faça commit
  dele (o `.gitignore` já exclui).
- Trocar o `token` exige editar `config.json` e reiniciar o bot (não dá para trocar token com o bot
  já rodando, por segurança).
- Se um candidato tiver DMs fechadas, o aviso de aprovação/recusa simplesmente não é enviado, mas o
  resultado continua sendo logado normalmente no canal de log.
